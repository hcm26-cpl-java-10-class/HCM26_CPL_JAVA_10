import { ConfigureAssessmentLink } from "./ConfigureAssessmentLink";
import { AssessmentLessonDialog } from "./AssessmentLessonDialog";
import { lessonApi } from "@/api";
import { aiCourseBuilderApi } from "@/api/features/demo/ai-course-builder.api";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import type { LessonContentType, LessonDTO, ValidationErrorResponse } from "@/types";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import axios from "axios";
import { Loader2, Sparkles } from "lucide-react";
import { type SyntheticEvent, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { formatDuration, LessonPreview } from "./LessonPreview";

interface LessonFormModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** Section mà bài học thuộc về (bắt buộc khi tạo mới). */
  sectionId: number;
  /** Có giá trị -> chế độ sửa, không có -> chế độ thêm mới. */
  lesson?: LessonDTO | null;
  /** Gợi ý orderIndex cho bài học mới (thường là max + 1). */
  defaultOrderIndex?: number;
  onSuccess?: (lesson: LessonDTO) => void;
}

interface FormState {
  title: string;
  contentType: LessonContentType;
  contentUrl: string;
  textContent: string;
  duration: string;
  orderIndex: string;
  allowSeeking: boolean;
}

const LESSON_CONTENT_TYPE_OPTIONS: { value: LessonContentType; label: string }[] = [
  { value: "VIDEO", label: "Video" },
  { value: "AUDIO", label: "Audio" },
  { value: "TEXT", label: "Text" },
  { value: "QUIZ", label: "Quiz" },
  { value: "EXAM", label: "Exam" },
  { value: "ASSIGNMENT", label: "Assignment" },
  { value: "DOCUMENT", label: "Document" },
  { value: "LINK", label: "Link" },
];

type FieldErrors = Partial<Record<keyof FormState, string>>;

const needsUrl = (type: LessonContentType) => ["VIDEO", "AUDIO", "DOCUMENT", "LINK"].includes(type);

function buildInitialState(lesson?: LessonDTO | null, defaultOrderIndex = 0): FormState {
  return {
    title: lesson?.title ?? "",
    contentType: lesson?.contentType ?? "VIDEO",
    contentUrl: lesson?.contentUrl ?? "",
    textContent: lesson?.textContent ?? "",
    duration: lesson?.duration != null ? String(lesson.duration) : "",
    orderIndex: String(lesson?.orderIndex ?? defaultOrderIndex),
    allowSeeking: lesson?.allowSeeking ?? false,
  };
}

function isHttpUrl(value: string): boolean {
  try {
    const url = new URL(value.trim());
    return url.protocol === "http:" || url.protocol === "https:";
  } catch {
    return false;
  }
}

/** Validate phía client, khớp với rule ở LessonDTO / LessonServiceImpl. */
function validate(form: FormState, outlineEditable: boolean): FieldErrors {
  const errors: FieldErrors = {};

  const title = form.title.trim();
  if (!title) errors.title = "Lesson title is required";
  else if (title.length > 200) errors.title = "Title must not exceed 200 characters";

  if (needsUrl(form.contentType)) {
    const url = form.contentUrl.trim();
    if (!url) errors.contentUrl = `Content URL is required for ${form.contentType} lessons`;
    else if (url.length > 500) errors.contentUrl = "Content URL must not exceed 500 characters";
    else if (!isHttpUrl(url)) errors.contentUrl = "Content URL must start with http:// or https://";
  } else if (!form.textContent.trim() && !outlineEditable) {
    errors.textContent = "Lesson content or assessment instructions are required";
  }

  if (form.duration !== "") {
    const d = Number(form.duration);
    if (!Number.isInteger(d) || d < 0) errors.duration = "Duration must be a non-negative whole number";
  }

  const order = Number(form.orderIndex);
  if (form.orderIndex === "" || !Number.isInteger(order) || order < 0) {
    errors.orderIndex = "Order index must be a non-negative whole number";
  }

  return errors;
}

function FieldMessage({ message }: { message?: string }) {
  if (!message) return null;
  return <p className="text-xs text-destructive">{message}</p>;
}

export function LessonFormModal({
  open,
  onOpenChange,
  sectionId,
  lesson,
  defaultOrderIndex = 0,
  onSuccess,
}: LessonFormModalProps) {
  const isEdit = !!lesson?.id;
  const queryClient = useQueryClient();
  const [form, setForm] = useState<FormState>(() => buildInitialState(lesson, defaultOrderIndex));
  const [errors, setErrors] = useState<FieldErrors>({});
  const [showPreview, setShowPreview] = useState(false);
  const [audioDurationStatus, setAudioDurationStatus] = useState<
    "idle" | "loading" | "loaded" | "error"
  >("idle");
  const [audioUploadStatus, setAudioUploadStatus] = useState<"idle" | "uploading" | "error">("idle");
  const [audioFileName, setAudioFileName] = useState("");
  const audioFileInputRef = useRef<HTMLInputElement>(null);
  const [documentUploadStatus, setDocumentUploadStatus] = useState<"idle" | "uploading" | "error">("idle");
  const [documentFileName, setDocumentFileName] = useState("");
  const documentFileInputRef = useRef<HTMLInputElement>(null);
  const [aiLoading, setAiLoading] = useState(false);

  // Reset form mỗi lần mở modal hoặc đổi bài học đang sửa
  useEffect(() => {
    if (open) {
      setForm(buildInitialState(lesson, defaultOrderIndex));
      setErrors({});
      setShowPreview(false);
      setAudioDurationStatus("idle");
      setAudioUploadStatus("idle");
      setAudioFileName("");
      setDocumentUploadStatus("idle");
      setDocumentFileName("");
    }
  }, [open, lesson, defaultOrderIndex]);

  useEffect(() => {
    setAudioDurationStatus(
      form.contentType === "AUDIO" && isHttpUrl(form.contentUrl) ? "loading" : "idle",
    );
  }, [form.contentType, form.contentUrl]);

  const setField = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => (prev[key] ? { ...prev, [key]: undefined } : prev));
  };

  const mutation = useMutation({
    mutationFn: async (payload: LessonDTO) => {
      // Dùng API service chung để request đi qua axiosInstance đã cấu hình
      // baseURL, JWT Authorization và refresh token của project.
      return isEdit
        ? await lessonApi.update(String(lesson!.id), payload)
        : await lessonApi.create(payload);
    },
    onSuccess: async (saved) => {
      await queryClient.invalidateQueries({ queryKey: ["lessons"] });
      toast.success(isEdit ? "Lesson updated." : "Lesson created.");
      onSuccess?.(saved);
      onOpenChange(false);
    },
    onError: (error: unknown) => {
      if (axios.isAxiosError(error)) {
        const body = error.response?.data as ValidationErrorResponse | undefined;
        // Backend trả 400 kèm { errors: { field: [msg] } } -> hiện lỗi dưới từng field
        if (error.response?.status === 400 && body?.errors) {
          const mapped: FieldErrors = {};
          Object.entries(body.errors).forEach(([field, messages]) => {
            mapped[field as keyof FormState] = messages?.[0];
          });
          setErrors(mapped);
          toast.error(body.message || "Please fix the highlighted fields.");
          return;
        }
        toast.error(error.response?.data?.message || "Could not save the lesson.");
        return;
      }
      toast.error("Could not save the lesson.");
    },
  });

  // AI writes the lesson text from the title (and any notes already typed). Nothing is saved until you press Save.
  const handleGenerateWithAi = async () => {
    if (!form.title.trim()) {
      toast.error("Enter the lesson title first.");
      return;
    }
    if (
      form.textContent.trim().length > 300 &&
      !window.confirm("Replace the current text with AI-generated content?")
    ) {
      return;
    }
    setAiLoading(true);
    try {
      const result = await aiCourseBuilderApi.draftLessonContent(sectionId, {
        title: form.title.trim(),
        notes: form.textContent,
        lessonId: lesson?.id,
      });
      if (result.content) {
        setField("textContent", result.content);
        toast.success("Content generated. Review it, then press Save.");
      }
    } catch (error: any) {
      toast.error(error?.response?.data?.message ?? "Could not generate content.");
    } finally {
      setAiLoading(false);
    }
  };

  const handleSubmit = () => {
    const found = validate(form, lesson?.outlineEditable === true);
    setErrors(found);
    if (Object.keys(found).length > 0) return;

    const payload: LessonDTO = {
      sectionId,
      title: form.title.trim(),
      contentType: form.contentType,
      orderIndex: Number(form.orderIndex),
    };
    if (form.duration !== "") payload.duration = Number(form.duration);

    // Chỉ gửi field có ý nghĩa với loại nội dung đang chọn
    if (form.contentType === "VIDEO" || form.contentType === "AUDIO") payload.allowSeeking = form.allowSeeking;
    if (needsUrl(form.contentType)) payload.contentUrl = form.contentUrl.trim();
    else payload.textContent = form.textContent;

    mutation.mutate(payload);
  };

  const previewLesson: LessonDTO = {
    title: form.title || "Preview",
    contentType: form.contentType,
    contentUrl: form.contentUrl,
    textContent: form.textContent,
    duration: form.duration !== "" ? Number(form.duration) : undefined,
  };

  const durationHint =
    form.duration !== "" && !errors.duration && Number.isFinite(Number(form.duration))
      ? `= ${formatDuration(Number(form.duration))}`
      : "In seconds";

  const detectAudioDuration = (event: SyntheticEvent<HTMLAudioElement>) => {
    const seconds = event.currentTarget.duration;
    if (!Number.isFinite(seconds) || seconds <= 0) {
      setAudioDurationStatus("error");
      return;
    }
    setField("duration", String(Math.ceil(seconds)));
    setAudioDurationStatus("loaded");
  };

  const handleAudioFile = async (file?: File) => {
    if (!file) return;
    setAudioFileName(file.name);
    if (!file.type.startsWith("audio/") || file.size > 25 * 1024 * 1024) {
      setAudioUploadStatus("error");
      toast.error("Choose an audio file up to 25 MB.");
      return;
    }

    const localUrl = URL.createObjectURL(file);
    const audio = new Audio(localUrl);
    audio.preload = "metadata";
    audio.onloadedmetadata = () => {
      if (Number.isFinite(audio.duration) && audio.duration > 0) {
        setField("duration", String(Math.ceil(audio.duration)));
      }
      URL.revokeObjectURL(localUrl);
    };
    audio.onerror = () => URL.revokeObjectURL(localUrl);

    setAudioUploadStatus("uploading");
    try {
      const uploaded = await lessonApi.uploadAudio(file);
      setField("contentUrl", uploaded.url);
      setAudioUploadStatus("idle");
      toast.success("Audio file uploaded.");
    } catch (error) {
      setAudioUploadStatus("error");
      toast.error(axios.isAxiosError(error) ? error.response?.data?.message || "Could not upload audio file." : "Could not upload audio file.");
    }
  };

  const handleDocumentFile = async (file?: File) => {
    if (!file) return;
    setDocumentFileName(file.name);
    if (file.size > 25 * 1024 * 1024 || !/\.(pdf|doc|docx|ppt|pptx|xls|xlsx|txt)$/i.test(file.name)) {
      setDocumentUploadStatus("error");
      toast.error("Choose a supported document file up to 25 MB.");
      return;
    }

    setDocumentUploadStatus("uploading");
    try {
      const uploaded = await lessonApi.uploadDocument(file);
      setField("contentUrl", uploaded.url);
      setDocumentUploadStatus("idle");
      toast.success("Document file uploaded.");
    } catch (error) {
      setDocumentUploadStatus("error");
      toast.error(axios.isAxiosError(error) ? error.response?.data?.message || "Could not upload document file." : "Could not upload document file.");
    }
  };

  const isBusy = mutation.isPending || audioUploadStatus === "uploading" || documentUploadStatus === "uploading";

  if (!isEdit && (form.contentType === "QUIZ" || form.contentType === "EXAM" || form.contentType === "ASSIGNMENT")) {
    return <AssessmentLessonDialog key={`${open}-${sectionId}-${form.contentType}`} open={open} onOpenChange={onOpenChange}
      sectionId={sectionId} type={form.contentType} initialTitle={form.title} initialInstructions={form.textContent}
      initialOrder={form.orderIndex} onBack={() => setField("contentType", "TEXT")} onSuccess={onSuccess} />;
  }

  return (
    <Dialog open={open} onOpenChange={(next) => !isBusy && onOpenChange(next)}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Edit lesson" : "Add lesson"}</DialogTitle>
          <DialogDescription>
            {isEdit
              ? `Update lesson #${lesson?.id} of section #${sectionId}.`
              : `Create a new lesson in section #${sectionId}.`}
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4">
          <div className="grid gap-1.5">
            <Label htmlFor="lesson-title">Title</Label>
            <Input
              id="lesson-title"
              value={form.title}
              maxLength={200}
              aria-invalid={!!errors.title}
              onChange={(e) => setField("title", e.target.value)}
              placeholder="e.g. Introduction to variables"
            />
            <p className="text-xs text-muted-foreground">Required · max 200 characters ({form.title.length}/200)</p>
            <FieldMessage message={errors.title} />
          </div>

          <div className="grid items-start gap-4 sm:grid-cols-3">
            <div className="grid grid-rows-[1.25rem_2.25rem_auto] gap-1.5">
              <Label>Content type</Label>
              <Select
                value={form.contentType}
                onValueChange={(v) => setField("contentType", v as LessonContentType)}
              >
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {LESSON_CONTENT_TYPE_OPTIONS.map((o) => (
                    <SelectItem key={o.value} value={o.value}>
                      {o.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-rows-[1.25rem_2.25rem_auto] gap-1.5">
              <Label htmlFor="lesson-duration">Duration</Label>
              <Input
                id="lesson-duration"
                type="number"
                min={0}
                step={1}
                value={form.duration}
                aria-invalid={!!errors.duration}
                onChange={(e) => setField("duration", e.target.value)}
              />
              {errors.duration ? (
                <FieldMessage message={errors.duration} />
              ) : (
                <p className="text-xs text-muted-foreground" aria-live="polite">
                  {audioDurationStatus === "loading"
                    ? "Detecting audio duration..."
                    : audioDurationStatus === "error"
                      ? "Could not detect duration · enter whole seconds manually"
                      : `Optional · whole seconds ≥ 0 ${durationHint !== "In seconds" ? durationHint : ""}`}
                </p>
              )}
            </div>

            <div className="grid grid-rows-[1.25rem_2.25rem_auto] gap-1.5">
              <Label htmlFor="lesson-order">Order index</Label>
              <Input
                id="lesson-order"
                type="number"
                min={0}
                step={1}
                value={form.orderIndex}
                aria-invalid={!!errors.orderIndex}
                onChange={(e) => setField("orderIndex", e.target.value)}
              />
              {errors.orderIndex ? (
                <FieldMessage message={errors.orderIndex} />
              ) : (
                <p className="text-xs text-muted-foreground">Whole number ≥ 0, unique in this section</p>
              )}
            </div>
          </div>

          {needsUrl(form.contentType) ? (
            <div className="grid gap-1.5">
              {form.contentType === "AUDIO" && (
                <>
                  <Label htmlFor="lesson-audio-file">Audio file</Label>
                  <Input
                    ref={audioFileInputRef}
                    id="lesson-audio-file"
                    type="file"
                    accept="audio/mpeg,audio/wav,audio/ogg,audio/mp4,audio/aac,audio/flac,audio/webm"
                    className="hidden"
                    disabled={isBusy}
                    onChange={(event) => void handleAudioFile(event.target.files?.[0])}
                  />
                  <div className="flex min-h-9 items-center gap-3 rounded-md border px-3 py-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      disabled={isBusy}
                      onClick={() => audioFileInputRef.current?.click()}
                    >
                      Choose audio file
                    </Button>
                    <span className="truncate text-sm text-muted-foreground">
                      {audioFileName || "No audio file chosen"}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground" aria-live="polite">
                    {audioUploadStatus === "uploading"
                      ? "Uploading audio file..."
                      : audioUploadStatus === "error"
                        ? "Upload failed · choose another file or use a URL"
                        : "MP3, WAV, OGG, M4A, AAC, FLAC or WEBM · max 25 MB"}
                  </p>
                  <div className="relative my-1 text-center text-xs text-muted-foreground before:absolute before:left-0 before:right-0 before:top-1/2 before:border-t">
                    <span className="relative bg-background px-2">or use an audio URL</span>
                  </div>
                </>
              )}
              {form.contentType === "DOCUMENT" && (
                <>
                  <Label htmlFor="lesson-document-file">Document file</Label>
                  <Input
                    ref={documentFileInputRef}
                    id="lesson-document-file"
                    type="file"
                    accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.txt"
                    className="hidden"
                    disabled={isBusy}
                    onChange={(event) => void handleDocumentFile(event.target.files?.[0])}
                  />
                  <div className="flex min-h-9 items-center gap-3 rounded-md border px-3 py-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      disabled={isBusy}
                      onClick={() => documentFileInputRef.current?.click()}
                    >
                      Choose document file
                    </Button>
                    <span className="truncate text-sm text-muted-foreground">
                      {documentFileName || "No document file chosen"}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground" aria-live="polite">
                    {documentUploadStatus === "uploading"
                      ? "Uploading document file..."
                      : documentUploadStatus === "error"
                        ? "Upload failed · choose another file or use a URL"
                        : "PDF, DOC, DOCX, PPT, PPTX, XLS, XLSX or TXT · max 25 MB"}
                  </p>
                  <div className="relative my-1 text-center text-xs text-muted-foreground before:absolute before:left-0 before:right-0 before:top-1/2 before:border-t">
                    <span className="relative bg-background px-2">or use a document URL</span>
                  </div>
                </>
              )}
              <Label htmlFor="lesson-url">
                {form.contentType === "VIDEO"
                  ? "Video URL"
                  : form.contentType === "AUDIO"
                    ? "Audio URL"
                    : "Resource URL"}
              </Label>
              <Input
                id="lesson-url"
                value={form.contentUrl}
                maxLength={500}
                aria-invalid={!!errors.contentUrl}
                onChange={(e) => setField("contentUrl", e.target.value)}
                placeholder={
                  form.contentType === "VIDEO"
                    ? "https://www.youtube.com/watch?v=..."
                    : form.contentType === "AUDIO"
                      ? "https://example.com/audio.mp3"
                      : "https://example.com/material.pdf"
                }
              />
              <p className="text-xs text-muted-foreground">
                Required · must start with http:// or https:// · max 500 characters
              </p>
              <FieldMessage message={errors.contentUrl} />
              {(form.contentType === "VIDEO" || form.contentType === "AUDIO") && (
                <div className="mt-2 flex items-center justify-between gap-4 rounded-md border px-3 py-2">
                  <div>
                    <Label htmlFor="lesson-allow-seeking">Allow learners to skip ahead</Label>
                    <p className="text-xs text-muted-foreground">
                      Off: learners cannot fast-forward past what they have watched (rewinding is allowed).
                    </p>
                  </div>
                  <Switch
                    id="lesson-allow-seeking"
                    checked={form.allowSeeking}
                    onCheckedChange={(checked) => setField("allowSeeking", checked)}
                  />
                </div>
              )}
              {form.contentType === "AUDIO" && isHttpUrl(form.contentUrl) && (
                <audio
                  key={form.contentUrl.trim()}
                  src={form.contentUrl.trim()}
                  preload="metadata"
                  className="hidden"
                  onLoadedMetadata={detectAudioDuration}
                  onError={() => setAudioDurationStatus("error")}
                />
              )}
            </div>
          ) : (
            <div className="grid gap-1.5">
              <div className="flex items-center justify-between gap-2">
                <Label htmlFor="lesson-text">{form.contentType === "TEXT" ? "Text content" : "Assessment instructions"}</Label>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  disabled={aiLoading || form.contentType !== "TEXT"}
                  onClick={handleGenerateWithAi}
                >
                  {aiLoading ? (
                    <Loader2 className="mr-1 h-4 w-4 animate-spin" />
                  ) : (
                    <Sparkles className="mr-1 h-4 w-4 text-amber-500" />
                  )}
                  Generate with AI
                </Button>
              </div>
              <Textarea
                id="lesson-text"
                rows={14}
                value={form.textContent}
                aria-invalid={!!errors.textContent}
                onChange={(e) => setField("textContent", e.target.value)}
                placeholder="Write the lesson content here..."
              />
              <p className="text-xs text-muted-foreground">
                {lesson?.outlineEditable
                  ? "You can save this outline while the course is Draft. Add content before publishing."
                  : "Enter lesson content or assessment instructions. Attach the assessment through Exam Management using this lesson."}
              </p>
              <FieldMessage message={errors.textContent} />
            </div>
          )}

          {showPreview && (
            <div className="rounded-xl border bg-muted/20 p-4">
              <LessonPreview lesson={previewLesson} hideHeader />
            </div>
          )}
        </div>

        <ConfigureAssessmentLink lesson={{ ...lesson, contentType: form.contentType, sectionId }} />
      <DialogFooter className="sm:justify-between">
          <Button
            type="button"
            variant="ghost"
            onClick={() => setShowPreview((v) => !v)}
            disabled={isBusy}
          >
            {showPreview ? "Hide preview" : "Preview content"}
          </Button>
          <div className="flex gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isBusy}
            >
              Cancel
            </Button>
            <Button type="button" onClick={handleSubmit} disabled={isBusy}>
              {audioUploadStatus === "uploading" || documentUploadStatus === "uploading" ? "Uploading..." : mutation.isPending ? "Saving..." : isEdit ? "Save changes" : "Create lesson"}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default LessonFormModal;