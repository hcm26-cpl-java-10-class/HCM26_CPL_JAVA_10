import { EXAM_CATEGORY_LABEL, type ExamCategory, type ExamDTO, type ExamType, type LatePolicy, type ResultVisibility } from "@/types";

export interface ExamConfigForm {
  startTime: string;
  endTime: string;
  maxAttempts: string;
  shuffleQuestions: boolean;
  shuffleOptions: boolean;
  showAnswersAfterExam: boolean;
  category: ExamCategory;
  passScore: string;
  maxScore: string;
  latePolicy: LatePolicy;
  latePenaltyPercent: string;
  lateGraceMinutes: string;
  resultVisibility: ResultVisibility;
  examType: ExamType;
  accessCode: string;
  // NEW (anti-cheat)
  antiCheatEnabled: boolean;
  detectTabSwitch: boolean;
  blockCopyPaste: boolean;
  requireFullscreen: boolean;
  singleSession: boolean;
}

export const DEFAULT_CONFIG: ExamConfigForm = {
  startTime: "",
  endTime: "",
  maxAttempts: "1",
  shuffleQuestions: false,
  shuffleOptions: false,
  showAnswersAfterExam: true,
  category: "ASSESSMENT",
  passScore: "",
  maxScore: "",
  latePolicy: "NOT_ALLOWED",
  latePenaltyPercent: "",
  lateGraceMinutes: "0",
  resultVisibility: "IMMEDIATE",
  examType: "MIXED",
  accessCode: "",
  antiCheatEnabled: false,
  detectTabSwitch: true,
  blockCopyPaste: true,
  requireFullscreen: false,
  singleSession: true,
};

export const LATE_POLICY_LABEL: Record<LatePolicy, string> = {
  NOT_ALLOWED: "Late submission not allowed",
  ALLOWED_WITH_PENALTY: "Allowed with point penalty",
  ALLOWED: "Allowed with no penalty",
};

export const EXAM_TYPE_LABEL: Record<ExamType, string> = {
  MULTIPLE_CHOICE: "Multiple Choice Only",
  ESSAY: "Essay Only",
  CODING: "Coding Only",
  MC_CODING: "Multiple Choice & Coding",
  MIXED: "Mixed (Multiple Choice, Essay & Coding)",
};

export const EXAM_CATEGORY_OPTIONS = Object.keys(EXAM_CATEGORY_LABEL) as ExamCategory[];

export const RESULT_VISIBILITY_LABEL: Record<ResultVisibility, string> = {
  IMMEDIATE: "View immediately after grading",
  AFTER_EXAM_CLOSED: "View after exam closes",
  MANUAL_RELEASE: "Manually released by teacher",
};

export const toInputDateTime = (value?: string | null) => (value ? value.slice(0, 16) : "");

export const getLocalDatetimeString = (date = new Date()) => {
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
};

export const getFutureDatetimeString = (minutesAhead: number) =>
  getLocalDatetimeString(new Date(Date.now() + minutesAhead * 60 * 1000));

export const configFromExam = (exam: ExamDTO): ExamConfigForm => ({
  startTime: toInputDateTime(exam.startTime),
  endTime: toInputDateTime(exam.endTime),
  maxAttempts: String(exam.maxAttempts ?? 1),
  shuffleQuestions: exam.shuffleQuestions ?? false,
  shuffleOptions: exam.shuffleOptions ?? false,
  showAnswersAfterExam: exam.showAnswersAfterExam ?? false,
  category: exam.category ?? "ASSESSMENT",
  passScore: exam.passScore != null ? String(exam.passScore) : "",
  maxScore: exam.maxScore != null ? String(exam.maxScore) : "",
  latePolicy: exam.latePolicy ?? "NOT_ALLOWED",
  latePenaltyPercent: exam.latePenaltyPercent != null ? String(exam.latePenaltyPercent) : "",
  lateGraceMinutes: String(exam.lateGraceMinutes ?? 0),
  resultVisibility: exam.resultVisibility ?? "IMMEDIATE",
  examType: exam.examType ?? "MIXED",
  accessCode: exam.accessCode ?? "",
  antiCheatEnabled: exam.antiCheatEnabled ?? false,
  detectTabSwitch: exam.detectTabSwitch ?? false,
  blockCopyPaste: exam.blockCopyPaste ?? false,
  requireFullscreen: exam.requireFullscreen ?? false,
  singleSession: exam.singleSession ?? false,
});

export function validateConfig(
    duration: number,
    cfg: ExamConfigForm,
    originalStartTime?: string,
    originalEndTime?: string,
): string | null {
  const now = Date.now() - 60 * 1000; // Allow 1-min grace when saving

  if (cfg.startTime) {
    const start = new Date(cfg.startTime).getTime();
    const isStartChanged = !originalStartTime || new Date(originalStartTime).getTime() !== start;
    if (isStartChanged && start < now) {
      return "Start time must be at current time or later (recommended: set at least 1 minute ahead so students have time to join).";
    }
  }

  if (cfg.endTime) {
    const end = new Date(cfg.endTime).getTime();
    const isEndChanged = !originalEndTime || new Date(originalEndTime).getTime() !== end;
    if (isEndChanged && end < now) {
      return "End time cannot be in the past.";
    }
  }

  if (cfg.startTime && cfg.endTime) {
    const start = new Date(cfg.startTime).getTime();
    const end = new Date(cfg.endTime).getTime();
    if (start >= end) return "End time must be after start time.";
    const windowMinutes = Math.floor((end - start) / 60000);
    if (duration > windowMinutes) return `Exam duration (${duration} mins) exceeds the available time window (${windowMinutes} mins).`;
  }
  if (!(Number(cfg.maxAttempts) >= 1)) return "Maximum attempts must be at least 1.";
  if (cfg.maxScore !== "" && !(Number(cfg.maxScore) > 0 && Number(cfg.maxScore) <= 1000)) return "Max score must be greater than 0 and at most 1000.";
  if (cfg.passScore !== "" && Number(cfg.passScore) < 0) return "Passing score must be >= 0.";
  if (cfg.passScore !== "" && Number(cfg.passScore) > (cfg.maxScore !== "" ? Number(cfg.maxScore) : 10)) return "Passing score cannot exceed the max score.";
  if (cfg.latePolicy !== "NOT_ALLOWED" && !cfg.endTime) return "End time is required when setting a late submission policy.";
  if (cfg.latePolicy === "ALLOWED_WITH_PENALTY") {
    const pct = Number(cfg.latePenaltyPercent);
    if (!(pct >= 1 && pct <= 100)) return "Late penalty percentage must be between 1% and 100%.";
  }
  if (Number(cfg.lateGraceMinutes) < 0) return "Grace period minutes must be >= 0.";
  if (cfg.latePolicy === "NOT_ALLOWED" && Number(cfg.lateGraceMinutes) > 0) return "Grace period can only be set when late submissions are allowed.";
  return null;
}

export const getErrorMessage = (error: unknown, fallback: string): string => {
  const err = error as { response?: { data?: { errors?: Record<string, string[]>; message?: string } } };
  const data = err?.response?.data;
  const fieldError = data?.errors ? (Object.values(data.errors).flat()[0]) : undefined;
  return fieldError || data?.message || fallback;
};

/** Request body for creating / updating an exam from the form values. */
export function buildExamRequest(title: string, duration: string, cfg: ExamConfigForm, isActive: boolean) {
  return {
    title: title.trim(),
    durationMinutes: Number(duration),
    isActive,
    startTime: cfg.startTime || undefined,
    endTime: cfg.endTime || undefined,
    maxAttempts: Number(cfg.maxAttempts),
    shuffleQuestions: cfg.shuffleQuestions,
    shuffleOptions: cfg.shuffleOptions,
    showAnswersAfterExam: cfg.showAnswersAfterExam,
    category: cfg.category,
    passScore: cfg.passScore !== "" ? Number(cfg.passScore) : undefined,
    maxScore: cfg.maxScore !== "" ? Number(cfg.maxScore) : undefined,
    latePolicy: cfg.latePolicy,
    latePenaltyPercent:
      cfg.latePolicy === "ALLOWED_WITH_PENALTY" && cfg.latePenaltyPercent !== ""
        ? Number(cfg.latePenaltyPercent)
        : undefined,
    lateGraceMinutes: Number(cfg.lateGraceMinutes || 0),
    resultVisibility: cfg.resultVisibility,
    examType: cfg.examType,
    accessCode: cfg.accessCode ? cfg.accessCode.trim() : "",
    antiCheatEnabled: cfg.antiCheatEnabled,
    detectTabSwitch: cfg.detectTabSwitch,
    blockCopyPaste: cfg.blockCopyPaste,
    requireFullscreen: cfg.requireFullscreen,
    singleSession: cfg.singleSession,
  };
}
