package com.example.starter_project_2025.system.exam.attempt.dto;

import java.math.BigDecimal;
import com.example.starter_project_2025.system.exam.attempt.domain.ExamAttemptStatus;
import com.example.starter_project_2025.system.question.core.domain.QuestionType;
import lombok.Getter;
import lombok.Setter;

import java.time.Instant;
import java.util.List;

@Getter
@Setter
public class ExamAttemptReviewDTO {
    private Long attemptId;
    private Long examId;
    private String title;
    private int attemptNumber;
    private ExamAttemptStatus status;
    private String revisionNote;
    private Instant revisionDeadline;
    private int totalPoints;
    private BigDecimal maxScore;
    private BigDecimal objectiveScore;
    private BigDecimal finalScore;
    private BigDecimal passScore;
    /** Dat/Truot theo diem dat da dong bang; chi co khi ket qua da cong bo. */
    private Boolean passed;
    private Instant submittedAt;
    /** Da duoc cong bo diem va dap an dung/sai hay chua. */
    private boolean revealAnswers;
    private List<QuestionReviewDTO> questions;

    @Getter
    @Setter
    public static class QuestionReviewDTO {
        private Long questionId;
        private String content;
        private String imageUrl;
        private QuestionType type;
        private int points;
        private BigDecimal maxScore;
        private Boolean correct;
        private List<OptionReviewDTO> options;
        private String textAnswer;
        private BigDecimal score;
        private String feedback;
    }

    @Getter
    @Setter
    public static class OptionReviewDTO {
        private Long id;
        private String content;
        private String imageUrl;
        private boolean correct;
        private boolean selected;
    }
}
