package com.example.starter_project_2025.system.exam.controller;

import com.example.starter_project_2025.system.exam.dto.EssayGradingDTO;
import com.example.starter_project_2025.system.exam.dto.ExamSimilarityDTO;
import com.example.starter_project_2025.system.exam.service.ExamEssayGradingService;
import com.example.starter_project_2025.system.exam.service.ExamSimilarityService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/exams/{examId}/grading")
@RequiredArgsConstructor
@PreAuthorize("hasAuthority('EXAM_UPDATE')")
public class ExamGradingController {

    private final ExamEssayGradingService service;
    private final ExamSimilarityService similarityService;

    @GetMapping("/attempts")
    public ResponseEntity<List<EssayGradingDTO.Summary>> listPending(@PathVariable Long examId) {
        return ResponseEntity.ok(service.listPending(examId));
    }

    @GetMapping("/attempts/{attemptId}")
    public ResponseEntity<EssayGradingDTO.Detail> getDetail(
            @PathVariable Long examId,
            @PathVariable Long attemptId
    ) {
        return ResponseEntity.ok(service.getDetail(examId, attemptId));
    }

    @PostMapping("/attempts/{attemptId}/grade")
    public ResponseEntity<EssayGradingDTO.Detail> submitOfficialGrade(
            @PathVariable Long examId,
            @PathVariable Long attemptId,
            @RequestBody EssayGradingDTO.GradeSubmissionRequest request
    ) {
        return ResponseEntity.ok(service.submitOfficialGrade(examId, attemptId, request));
    }

    /** Lay Reference Answer va Rubric da submit cho mot cau hoi trong de thi. */
    @GetMapping("/questions/{questionId}/guidelines")
    public ResponseEntity<EssayGradingDTO.QuestionGuidelineDTO> getQuestionGuidelines(
            @PathVariable Long examId,
            @PathVariable Long questionId
    ) {
        return ResponseEntity.ok(service.getQuestionGuidelines(examId, questionId));
    }

    /** Submit Reference Answer (Model Answer) cho cau hoi trong de thi. */
    @PutMapping("/questions/{questionId}/reference")
    public ResponseEntity<EssayGradingDTO.QuestionGuidelineDTO> submitReferenceAnswer(
            @PathVariable Long examId,
            @PathVariable Long questionId,
            @RequestBody(required = false) EssayGradingDTO.SubmitReferenceRequest request
    ) {
        return ResponseEntity.ok(service.submitReferenceAnswer(
                examId,
                questionId,
                request != null ? request.getReferenceAnswer() : ""
        ));
    }

    /** Submit Grading Rubric & Criteria cho cau hoi trong de thi. */
    @PutMapping("/questions/{questionId}/rubric")
    public ResponseEntity<EssayGradingDTO.QuestionGuidelineDTO> submitRubric(
            @PathVariable Long examId,
            @PathVariable Long questionId,
            @RequestBody(required = false) EssayGradingDTO.SubmitRubricRequest request
    ) {
        return ResponseEntity.ok(service.submitRubric(
                examId,
                questionId,
                request != null ? request.getRubric() : ""
        ));
    }

    /** Chay thu toan bo test cua mot cau lap trinh tren code sinh vien (khong luu gi). */
    @PostMapping("/attempts/{attemptId}/coding/{questionId}/run")
    public ResponseEntity<EssayGradingDTO.CodingRunResult> runCoding(
            @PathVariable Long examId,
            @PathVariable Long attemptId,
            @PathVariable Long questionId
    ) {
        return ResponseEntity.ok(service.runCodingTests(examId, attemptId, questionId));
    }

    /** Cham lai cau lap trinh bang may cham va luu diem. */
    @PostMapping("/attempts/{attemptId}/coding/{questionId}/regrade")
    public ResponseEntity<EssayGradingDTO.Detail> regradeCoding(
            @PathVariable Long examId,
            @PathVariable Long attemptId,
            @PathVariable Long questionId
    ) {
        return ResponseEntity.ok(service.regradeCoding(examId, attemptId, questionId));
    }

    @PostMapping("/attempts/{attemptId}/ai-suggest")
    public ResponseEntity<EssayGradingDTO.AiGradingResponse> requestAiGrading(
            @PathVariable Long examId,
            @PathVariable Long attemptId,
            @RequestBody(required = false) EssayGradingDTO.AiGradingRequest request
    ) {
        return ResponseEntity.ok(service.requestAiGrading(examId, attemptId, request));
    }

    @GetMapping("/similarity")
    public ResponseEntity<ExamSimilarityDTO.SimilarityReport> getSimilarityReport(@PathVariable Long examId) {
        return ResponseEntity.ok(similarityService.scanExamSimilarity(examId));
    }

    @PostMapping("/similarity/scan")
    public ResponseEntity<ExamSimilarityDTO.SimilarityReport> triggerSimilarityScan(@PathVariable Long examId) {
        return ResponseEntity.ok(similarityService.scanExamSimilarity(examId));
    }
}
