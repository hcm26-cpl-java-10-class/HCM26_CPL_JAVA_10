package com.example.starter_project_2025.system.exam.domain;

import com.example.starter_project_2025.base.crud.domain.BaseEntity;
import com.example.starter_project_2025.init.annotation.ResourceMenu;
import com.example.starter_project_2025.init.annotation.ResourcePermission;
import com.example.starter_project_2025.system.rbac.user.User;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;

@Entity
@Table(name = "exam_invitation")
@ResourcePermission("INVITATION")
@ResourceMenu(
        title = "Invitations",
        group = "Assessment Management",
        icon = "mail",
        url = "/invitations",
        order = 2,
        permission = "INVITATION_READ"
)
@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class Invitation extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "exam_id", nullable = false)
    private Exam exam;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User user;

    @Column(nullable = false, unique = true, length = 64)
    private String token;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    private InvitationStatus status = InvitationStatus.PENDING;

    private LocalDateTime sentAt;

    @Column(name = "available_from")
    private LocalDateTime availableFrom;

    private LocalDateTime expiresAt;

    private LocalDateTime acceptedAt;

    private LocalDateTime rejectedAt;

    private LocalDateTime revokedAt;

    @Column(length = 500)
    private String revokedReason;

    @Column(length = 500)
    private String note;

    @Builder.Default
    @Column(nullable = false)
    private Integer resendCount = 0;

    @Builder.Default
    @Column(nullable = false)
    private Boolean anonymous = false;

    @Column(length = 100)
    private String guestName;

    @Column(length = 150)
    private String guestEmail;

    @Column(name = "guest_user_id")
    private Long guestUserId;

    @Column(length = 10, unique = true)
    private String accessCode;

    private LocalDateTime maxAccessTime;

    @Builder.Default
    @Column(nullable = false)
    private Integer maxAccessAttempts = 1;

    @Builder.Default
    @Column(nullable = false)
    private Integer accessAttemptCount = 0;

    /** Nguồn tạo lời mời: MANUAL (tạo lẻ) hoặc COURSE (bulk theo lớp). */
    @Builder.Default
    @Column(name = "source_type", nullable = false, length = 20)
    private String sourceType = "MANUAL";

    /** Lớp (course) dùng làm nguồn khi tạo lời mời hàng loạt. */
    @Column(name = "source_course_id")
    private Long sourceCourseId;
}
