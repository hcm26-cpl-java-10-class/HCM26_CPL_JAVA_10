import { assessmentPreparationPath, learnerAssessmentReturnPath } from '@/utils/assessment-navigation';
import {
    runCode,
    saveExamAnswers,
    sendEntryPhoto,
    sendIntegrityEvents, // NEW (anti-cheat)
    getCurrentExamAttempt,
    submitExamAttempt,
    type ExamAttemptAnswer,
    type SaveExamAnswerRequest,
} from '@/api/exam.api';
import { formatScore, questionScore } from '@/utils/examScore';
import { Button } from '@/components/ui/button';
import { MainLayout } from '@/components/layout/MainLayout';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import axios from 'axios';
import { useEffect, useRef, useState } from 'react';
import { useLocation, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { Loader2, Star, WifiOff } from 'lucide-react';
import { toast } from 'sonner';
import { CodingWorkspace } from './components/CodingWorkspace';
import { EssayPopup } from './components/EssayPopup';
import { ExamIntegrityNotice, useExamIntegrity } from '@/hooks/useExamIntegrity'; // NEW (anti-cheat)
import { FontSizeControl, useQuestionFontSize } from '@/hooks/useQuestionFontSize';
import { SubmitConfirmOverlay } from '@/components/exam/SubmitConfirmOverlay';

const attemptQueryKey = (examId: number) => ['student-exam-attempt', examId] as const;

interface ExtendedAnswer extends ExamAttemptAnswer {
    saved?: boolean;
}

interface ExtendedSaveRequest extends SaveExamAnswerRequest {
    markSaved?: boolean;
}

function toAnswerRequests(answers: Record<number, ExtendedAnswer>): SaveExamAnswerRequest[] {
    return Object.values(answers).map((answer) => ({
        questionId: answer.questionId,
        selectedOptionIds: answer.selectedOptionIds,
        textAnswer: answer.textAnswer,
    }));
}

// ----- Local copy of unsent work (survives network loss / closing the tab) -----
const draftKey = (attemptId: number) => `exam-drafts-${attemptId}`;

function sameAnswer(
    a: { selectedOptionIds?: number[]; textAnswer?: string | null } | undefined,
    b: { selectedOptionIds?: number[]; textAnswer?: string | null } | undefined,
): boolean {
    const norm = (x: typeof a) =>
        JSON.stringify({
            o: [...(x?.selectedOptionIds ?? [])].sort((p, q) => p - q),
            t: x?.textAnswer ?? '',
        });
    return norm(a) === norm(b);
}

function readDrafts(attemptId: number): Record<number, SaveExamAnswerRequest> {
    try {
        const raw = localStorage.getItem(draftKey(attemptId));
        return raw ? (JSON.parse(raw) as Record<number, SaveExamAnswerRequest>) : {};
    } catch {
        return {};
    }
}

function writeDrafts(attemptId: number, drafts: Record<number, SaveExamAnswerRequest>) {
    try {
        if (Object.keys(drafts).length === 0) localStorage.removeItem(draftKey(attemptId));
        else localStorage.setItem(draftKey(attemptId), JSON.stringify(drafts));
    } catch {
        // storage unavailable: the server copy still works
    }
}

function getStartErrorMessage(error: unknown): string {
    if (axios.isAxiosError(error)) {
        if (!error.response) return 'Cannot connect to server. Please check your network connection and try again.';
        const message = (error.response.data as { message?: string } | undefined)?.message;
        if (error.response.status === 403) return 'You do not have permission to take this exam.';
        if (error.response.status === 404) return 'Exam not found or has been disabled.';
        if (message) return message;
    }
    return 'Unable to open exam. Please try again.';
}

function getCountdown(deadlineAt: string, now: number): number {
    return Math.max(0, Math.ceil((new Date(deadlineAt).getTime() - now) / 1000));
}

function formatCountdown(totalSeconds: number): string {
    const minutes = Math.floor(totalSeconds / 60).toString().padStart(2, '0');
    const seconds = (totalSeconds % 60).toString().padStart(2, '0');
    return `${minutes}:${seconds}`;
}

export default function StudentExamTakingPage() {
    const { examId: rawExamId } = useParams();
    const examId = Number(rawExamId);
    const validExamId = Number.isSafeInteger(examId) && examId > 0;
    const location = useLocation();
    const navigate = useNavigate();
    const navigationState = location.state as { returnTo?: unknown } | null;
    const returnTo = learnerAssessmentReturnPath(new URLSearchParams(location.search).get('returnTo') ?? navigationState?.returnTo);
    const isCourseReturnPath = returnTo.startsWith('/enrollments/') || returnTo.startsWith('/courses/');
    const returnLabel = returnTo === '/invitations'
        ? 'Back to Invitations'
        : isCourseReturnPath
            ? 'Back to Course'
            : 'Back to Exam Schedule';
    const returnCrumbLabel = returnTo === '/invitations'
        ? 'Invitations'
        : isCourseReturnPath
            ? 'Course Learning'
            : 'Exam Schedule';
    const [searchParams, setSearchParams] = useSearchParams();
    const essayParam = Number(searchParams.get('essay'));
    const codeParam = Number(searchParams.get('code'));
    const queryClient = useQueryClient();
    const timerRefs = useRef(new Map<number, number>());
    const autoSubmitStarted = useRef(false);
    const submitStartedRef = useRef(false);

    const pendingAnswersRef = useRef(
        new Map<number, ExtendedSaveRequest>(),
    );
    const savingRef = useRef(false);
    const draftsRef = useRef<Record<number, SaveExamAnswerRequest>>({});
    const warnedRef = useRef(new Set<number>());
    const timeUpRef = useRef(false);
    const [isSaving, setIsSaving] = useState(false);
    const [hasSaveError, setHasSaveError] = useState(false);
    const [isOnline, setIsOnline] = useState(() => (typeof navigator === 'undefined' ? true : navigator.onLine));
    useEffect(() => {
        const up = () => setIsOnline(true);
        const down = () => setIsOnline(false);
        window.addEventListener('online', up);
        window.addEventListener('offline', down);
        return () => {
            window.removeEventListener('online', up);
            window.removeEventListener('offline', down);
        };
    }, []);

    const [answers, setAnswers] = useState<Record<number, ExtendedAnswer>>({});
    const answersRef = useRef(answers);
    answersRef.current = answers;

    const [now, setNow] = useState(() => Date.now());

    const attemptQuery = useQuery({
        queryKey: validExamId ? attemptQueryKey(examId) : ['student-exam-attempt', 'invalid'],
        queryFn: () => getCurrentExamAttempt(examId),
        enabled: validExamId,
        retry: false,
        refetchOnWindowFocus: false,
        refetchOnReconnect: false,
        staleTime: Infinity,
    });

    const submitMutation = useMutation({
        mutationFn: ({ attemptId, submittedAnswers }: { attemptId: number; submittedAnswers: SaveExamAnswerRequest[] }) =>
            submitExamAttempt(attemptId, submittedAnswers),
        onSuccess: (attempt) => {
            queryClient.setQueryData(attemptQueryKey(examId), attempt);
            draftsRef.current = {};
            writeDrafts(attempt.id, {});
            clearAllPendingSaves();
            queryClient.invalidateQueries({ queryKey: ["my-exam-scores"] });
            queryClient.invalidateQueries({ queryKey: ["exam-preparation", examId] });
            queryClient.invalidateQueries({ queryKey: ["student-exam-attempts"] });
            queryClient.invalidateQueries({ queryKey: ["lesson-progress"] });
            queryClient.invalidateQueries({ queryKey: ["course-exams"] });
            if (attempt.status === 'EXPIRED') {
                toast.warning('Time is up! Your exam has been automatically submitted.');
            } else {
                toast.success(attempt.status === 'PENDING_REVIEW' ? 'Submitted successfully! Essay questions are pending review.' : 'Submitted successfully!');
            }
        },
        onError: () => {
            // While the time-up dialog is retrying automatically, do not spam toasts.
            if (!timeUpRef.current) toast.error('Failed to submit exam. Please try again.');
        },
    });

    const attempt = attemptQuery.data;

    // NEW (anti-cheat): theo doi tab / chan copy-paste / toan man hinh
    const integrity = useExamIntegrity({
        attemptId: attempt?.id,
        config: attempt?.integrity,
        active: attempt?.status === 'IN_PROGRESS',
        send: sendIntegrityEvents,
        sendEntryPhoto,
        onEntryPhotoSaved: () => void attemptQuery.refetch(),
        supervisorStreaming: true,

    });

    const questionFont = useQuestionFontSize();
    const [confirmText, setConfirmText] = useState<string | null>(null);
    const skipConfirmRef = useRef(false);
    const [flagged, setFlagged] = useState<Set<number>>(new Set());
    const [activeQuestionId, setActiveQuestionId] = useState<number | null>(null);
    const flagKey = attempt ? `exam-flagged-${attempt.id}` : null;

    useEffect(() => {
        if (!flagKey) return;
        try {
            const raw = localStorage.getItem(flagKey);
            setFlagged(new Set<number>(raw ? JSON.parse(raw) : []));
        } catch {
            setFlagged(new Set());
        }
    }, [flagKey]);

    const toggleFlag = (questionId: number) => {
        setFlagged((prev) => {
            const next = new Set(prev);
            if (next.has(questionId)) next.delete(questionId);
            else next.add(questionId);
            if (flagKey) {
                try {
                    localStorage.setItem(flagKey, JSON.stringify([...next]));
                } catch {
                }
            }
            return next;
        });
    };

    function clearAllPendingSaves() {
        timerRefs.current.forEach((timer) => window.clearTimeout(timer));
        timerRefs.current.clear();
        pendingAnswersRef.current.clear();
    }

    const flushPendingAnswers = async (
        attemptId: number,
    ): Promise<boolean> => {
        while (savingRef.current) {
            await new Promise<void>((resolve) => {
                window.setTimeout(resolve, 50);
            });
        }

        if (pendingAnswersRef.current.size === 0) {
            setHasSaveError(false);
            return true;
        }

        savingRef.current = true;
        setIsSaving(true);

        try {
            while (pendingAnswersRef.current.size > 0) {
                const entry = pendingAnswersRef.current.entries().next().value as
                    | [number, ExtendedSaveRequest]
                    | undefined;

                if (!entry) break;

                const [questionId, request] = entry;
                pendingAnswersRef.current.delete(questionId);

                try {
                    const saved = await saveExamAnswers(attemptId, [request]);
                    if (saved.status !== 'IN_PROGRESS') {
                        clearAllPendingSaves();
                        queryClient.setQueryData(attemptQueryKey(examId), saved);
                        toast.warning(
                            saved.status === 'EXPIRED'
                                ? 'Time is up! Your exam has been automatically submitted.'
                                : 'This exam has already been submitted (possibly from another tab). Latest changes were not saved.',
                        );
                        setHasSaveError(false);
                        return true;
                    }
                    const draft = draftsRef.current[questionId];
                    if (draft && sameAnswer(draft, request)) {
                        delete draftsRef.current[questionId];
                        writeDrafts(attemptId, draftsRef.current);
                    }
                } catch {
                    if (!pendingAnswersRef.current.has(questionId)) {
                        pendingAnswersRef.current.set(questionId, request);
                    }

                    setHasSaveError(true);
                    return false;
                }
            }

            setHasSaveError(false);
            return true;
        } finally {
            savingRef.current = false;
            setIsSaving(pendingAnswersRef.current.size > 0);
        }
    };

    useEffect(() => {
        if (!attempt) return;
        let merged: Record<number, ExtendedAnswer> = Object.fromEntries(
            attempt.answers.map((answer) => [answer.questionId, answer]),
        );
        draftsRef.current = {};
        if (attempt.status === 'IN_PROGRESS') {
            // Restore work that never reached the server (lost connection, closed tab...)
            const stored = readDrafts(attempt.id);
            let restored = 0;
            for (const draft of Object.values(stored)) {
                const server = merged[draft.questionId];
                if (sameAnswer(server, draft)) continue;
                draftsRef.current[draft.questionId] = draft;
                merged = {
                    ...merged,
                    [draft.questionId]: {
                        ...(server ?? { questionId: draft.questionId, selectedOptionIds: [], textAnswer: null }),
                        selectedOptionIds: draft.selectedOptionIds ?? [],
                        textAnswer: draft.textAnswer ?? null,
                    },
                };
                pendingAnswersRef.current.set(draft.questionId, draft);
                restored += 1;
            }
            writeDrafts(attempt.id, draftsRef.current);
            if (restored > 0) {
                toast.info(`Restored ${restored} answer(s) that had not been sent to the server. Sending them now.`);
                void flushPendingAnswers(attempt.id);
            }
        }
        setAnswers(merged);
        autoSubmitStarted.current = false;
    }, [attempt?.id]);

    useEffect(() => {
        if (attempt?.status !== 'IN_PROGRESS') return;
        const interval = window.setInterval(() => setNow(Date.now()), 1000);
        return () => window.clearInterval(interval);
    }, [attempt?.status]);

    useEffect(() => {
        if (!attempt || attempt.status !== 'IN_PROGRESS') return;

        const retryPendingAnswers = () => {
            void flushPendingAnswers(attempt.id);
        };

        window.addEventListener('online', retryPendingAnswers);

        return () => {
            window.removeEventListener('online', retryPendingAnswers);
        };
    }, [attempt?.id, attempt?.status]);

    useEffect(() => {
        if (!hasSaveError || !attempt || attempt.status !== 'IN_PROGRESS') return;
        const id = window.setInterval(() => {
            void flushPendingAnswers(attempt.id);
        }, 15000);
        return () => window.clearInterval(id);
    }, [hasSaveError, attempt?.id, attempt?.status]);

    useEffect(() => () => {
        timerRefs.current.forEach((timer) => window.clearTimeout(timer));
        timerRefs.current.clear();
    }, []);

    useEffect(() => {
        if (attempt?.status !== 'IN_PROGRESS') return;

        const warnBeforeUnload = (event: BeforeUnloadEvent) => {
            event.preventDefault();
            event.returnValue = '';
        };

        window.addEventListener('beforeunload', warnBeforeUnload);

        return () => {
            window.removeEventListener('beforeunload', warnBeforeUnload);
        };
    }, [attempt?.id, attempt?.status]);

    const submitCurrentAnswers = async (requireConfirmation = false) => {
        if (
            !attempt ||
            attempt.status !== 'IN_PROGRESS' ||
            submitMutation.isPending ||
            submitStartedRef.current
        ) {
            return;
        }

        if (requireConfirmation && !skipConfirmRef.current) {
            // In-page dialog: a native confirm() would take the browser out of fullscreen.
            const unsaved = attempt.questions.filter((q) => q.type === 'ESSAY' && !answersRef.current[q.id]?.saved).length;
            const unanswered = attempt.questions.filter((q) => {
                const a = answersRef.current[q.id];
                return q.type === 'ESSAY' || q.type === 'CODING'
                    ? (a?.textAnswer ?? '').trim().length === 0
                    : (a?.selectedOptionIds.length ?? 0) === 0;
            }).length;
            setConfirmText(
                'Are you sure you want to submit your exam? Please double-check your answers before proceeding.' +
                (unanswered > 0 ? `\n\nYou have ${unanswered} unanswered question(s) out of ${attempt.questions.length}.` : '') +
                (unsaved > 0 ? `\n\nThere are ${unsaved} essay question(s) that have not been saved (unsaved content will still be submitted).` : ''),
            );
            return;
        }
        skipConfirmRef.current = false;

        submitStartedRef.current = true;

        timerRefs.current.forEach((timer) => window.clearTimeout(timer));
        timerRefs.current.clear();

        try {
            const saved = await flushPendingAnswers(attempt.id);

            if (!saved && requireConfirmation) {
                toast.error(
                    'Failed to save some answers. Please check your network connection and try again.',
                );
                return;
            }

            await submitMutation.mutateAsync({
                attemptId: attempt.id,
                submittedAnswers: toAnswerRequests(answersRef.current),
            });

            pendingAnswersRef.current.clear();
            setHasSaveError(false);
        } catch {
        } finally {
            submitStartedRef.current = false;
        }
    };

    const secondsRemaining = attempt ? getCountdown(attempt.deadlineAt, now) : 0;

    useEffect(() => {
        if (
            attempt?.status === 'IN_PROGRESS'
            && secondsRemaining === 0
            && !autoSubmitStarted.current
            && !submitMutation.isPending
        ) {
            autoSubmitStarted.current = true;
            void submitCurrentAnswers();
        }
    }, [attempt?.status, secondsRemaining, submitMutation.isPending]);

    const isTimeUp = attempt?.status === 'IN_PROGRESS' && secondsRemaining === 0;
    timeUpRef.current = isTimeUp;

    // Time-up: keep trying to submit (every 5 s) until the server accepts it.
    useEffect(() => {
        if (!isTimeUp) return;
        const id = window.setInterval(() => {
            void submitCurrentAnswers();
        }, 5000);
        return () => window.clearInterval(id);
    }, [isTimeUp]);

    // Warn at 5 minutes and 1 minute left
    useEffect(() => {
        if (attempt?.status !== 'IN_PROGRESS' || secondsRemaining <= 0) return;
        if (secondsRemaining <= 60 && !warnedRef.current.has(60)) {
            warnedRef.current.add(60);
            warnedRef.current.add(300);
            toast.warning('1 minute left. Your answers are saved automatically; submit when you are ready.');
        } else if (secondsRemaining <= 300 && secondsRemaining > 60 && !warnedRef.current.has(300)) {
            warnedRef.current.add(300);
            toast.warning('5 minutes left.');
        }
    }, [secondsRemaining, attempt?.status]);

    const scheduleAnswerSave = (
        questionId: number,
        answer: ExtendedAnswer,
    ) => {
        if (!attempt || attempt.status !== 'IN_PROGRESS') return;

        const existingTimer = timerRefs.current.get(questionId);

        if (existingTimer !== undefined) {
            window.clearTimeout(existingTimer);
        }

        const timer = window.setTimeout(() => {
            pendingAnswersRef.current.set(questionId, {
                questionId,
                selectedOptionIds: [...answer.selectedOptionIds],
                textAnswer: answer.textAnswer,
            });

            timerRefs.current.delete(questionId);
            void flushPendingAnswers(attempt.id);
        }, 400);

        timerRefs.current.set(questionId, timer);
    };

    const updateAnswer = (questionId: number, update: Partial<ExtendedAnswer>) => {
        const current = answers[questionId] ?? {
            questionId,
            selectedOptionIds: [],
            textAnswer: null,
        };
        const next = { ...current, ...update };
        if (update.textAnswer !== undefined && (update.textAnswer ?? '') !== (current.textAnswer ?? '')) {
            next.saved = false;
        }
        if (attempt && attempt.status === 'IN_PROGRESS') {
            draftsRef.current[questionId] = {
                questionId,
                selectedOptionIds: next.selectedOptionIds,
                textAnswer: next.textAnswer,
            };
            writeDrafts(attempt.id, draftsRef.current);
        }
        setAnswers((currentAnswers) => ({ ...currentAnswers, [questionId]: next }));
        scheduleAnswerSave(questionId, next);
    };

    const openEssay = (questionId: number) =>
        setSearchParams({ returnTo, essay: String(questionId) }, { state: { ...location.state, returnTo } });
    const openCode = (questionId: number) =>
        setSearchParams({ returnTo, code: String(questionId) }, { state: { ...location.state, returnTo } });
    const closeEssay = () => setSearchParams({ returnTo }, { state: { ...location.state, returnTo } });

    const hasText = (questionId: number) => (answers[questionId]?.textAnswer ?? '').trim().length > 0;
    const isAnswered = (question: { id: number; type: string }) =>
        question.type === 'ESSAY' || question.type === 'CODING'
            ? hasText(question.id)
            : (answers[question.id]?.selectedOptionIds.length ?? 0) > 0;

    const saveEssay = async (questionId: number) => {
        if (!attempt || attempt.status !== 'IN_PROGRESS') return;
        if (!hasText(questionId)) {
            toast.error('Please enter your answer before saving.');
            return;
        }
        const timer = timerRefs.current.get(questionId);
        if (timer !== undefined) {
            window.clearTimeout(timer);
            timerRefs.current.delete(questionId);
        }
        const current = answersRef.current[questionId];
        pendingAnswersRef.current.set(questionId, {
            questionId,
            selectedOptionIds: [],
            textAnswer: current?.textAnswer ?? '',
            markSaved: true,
        });
        const ok = await flushPendingAnswers(attempt.id);
        if (!ok) {
            toast.error('Could not save answer. Please check your network connection and click Save again.');
            return;
        }
        setAnswers((all) => ({ ...all, [questionId]: { ...all[questionId], questionId, saved: true } as ExtendedAnswer }));
        toast.success('Answer saved successfully.');
        closeEssay();
    };

    const jumpToQuestion = (question: { id: number; type: string }) => {
        setActiveQuestionId(question.id);
        if (question.type === 'ESSAY') {
            openEssay(question.id);
            return;
        }
        if (question.type === 'CODING') {
            openCode(question.id);
            return;
        }
        if (essayParam || codeParam) closeEssay();
        window.setTimeout(() => document.getElementById(`question-card-${question.id}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 50);
    };

    if (!validExamId) {
        return (
            <MainLayout>
                <div role="alert" className="rounded-lg border border-destructive p-6 text-destructive">
                    Invalid exam ID.
                </div>
            </MainLayout>
        );
    }

    if (attemptQuery.isLoading) {
        return <MainLayout><p className="p-6">Loading exam...</p></MainLayout>;
    }

    if (attemptQuery.isError || !attempt) {
        return (
            <MainLayout>
                <div role="alert" className="space-y-4 rounded-lg border border-destructive p-6 text-destructive">
                    <p>{getStartErrorMessage(attemptQuery.error)}</p>
                    <Button variant="outline" onClick={() => navigate(assessmentPreparationPath(examId, returnTo))}>Assessment overview</Button>
                    <Button variant="outline" onClick={() => navigate(returnTo)}>{returnLabel}</Button>
                </div>
            </MainLayout>
        );
    }

    const isFinished = attempt.status !== 'IN_PROGRESS';
    // Diem chi duoc hien thi khi giao vien da cong bo ket qua (Publish Results).
    const isResultPublished = attempt.resultPublished !== false;
    const codingQuestions = attempt.questions.filter((q) => q.type === 'CODING');
    const currentCode = attempt.questions.find((q) => q.id === codeParam && q.type === 'CODING');
    const currentEssay = attempt.questions.find((q) => q.id === essayParam && q.type === 'ESSAY');
    const currentEssayIndex = currentEssay ? attempt.questions.indexOf(currentEssay) : -1;
    const currentTextQuestion = currentCode ?? currentEssay;
    const currentAnswer = currentTextQuestion ? answers[currentTextQuestion.id] : undefined;
    const currentSaved = Boolean(currentAnswer?.saved);

    const activeId = currentCode ? currentCode.id : currentEssay ? currentEssay.id : activeQuestionId;

    const timerBox = (
        <div role="timer" aria-live="polite" className={`pointer-events-auto shrink-0 rounded-lg border bg-card px-4 py-2 font-mono text-xl ${secondsRemaining <= 60 ? 'border-red-500 text-red-500' : ''} ${secondsRemaining > 0 && secondsRemaining <= 60 ? 'animate-pulse' : ''}`}>
            {formatCountdown(secondsRemaining)}
        </div>
    );

    const confirmOverlay = confirmText ? (
        <SubmitConfirmOverlay
            message={confirmText}
            onCancel={() => setConfirmText(null)}
            onConfirm={() => {
                setConfirmText(null);
                skipConfirmRef.current = true;
                void submitCurrentAnswers(true);
            }}
        />
    ) : null;

    const timeUpOverlay = isTimeUp ? (
        <div
            role="alertdialog"
            aria-modal="true"
            aria-labelledby="time-up-title"
            className="fixed inset-0 z-[100] flex items-center justify-center bg-background/80 p-4 backdrop-blur-sm"
        >
            <div className="w-full max-w-md rounded-xl border bg-card p-6 text-center shadow-lg">
                <Loader2 className="mx-auto h-8 w-8 animate-spin text-muted-foreground" />
                <h2 id="time-up-title" className="mt-4 text-lg font-semibold">Time is up: submitting your exam</h2>
                <p className="mt-2 text-sm text-muted-foreground">
                    Everything you have typed so far, including code and essay text you did not save, is being submitted.
                    Please do not close this page.
                </p>
                {submitMutation.isError && (
                    <p role="alert" className="mt-3 text-sm text-destructive">
                        Could not reach the server. Retrying automatically; your answers are kept on this device.
                    </p>
                )}
            </div>
        </div>
    ) : null;

    const starButton = (questionId: number, number: number) => {
        const isFlagged = flagged.has(questionId);
        return (
            <button
                type="button"
                onClick={() => toggleFlag(questionId)}
                aria-pressed={isFlagged}
                aria-label={isFlagged ? `Unflag question ${number}` : `Flag question ${number}`}
                title={isFlagged ? 'Unflag' : 'Flag this question'}
                className="rounded-md p-1 transition-colors hover:bg-muted"
            >
                <Star className={`h-5 w-5 ${isFlagged ? 'fill-yellow-400 text-yellow-400' : 'text-muted-foreground'}`} />
            </button>
        );
    };

    const pinnedBar = (
        <div className="pointer-events-none sticky top-3 z-30 flex h-0 items-start justify-between gap-4">
            {timerBox}
            <div className="pointer-events-auto flex w-[11.5rem] shrink-0 flex-col gap-2 rounded-xl border bg-card p-2.5 shadow-sm">
                <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] text-muted-foreground">
                    <span className="w-full text-sm font-semibold text-foreground">Questions Navigation</span>
                    <span className="flex items-center gap-1"><span className="inline-block h-3 w-3 rounded-sm bg-black ring-1 ring-border" /> Unanswered</span>
                    <span className="flex items-center gap-1"><span className="inline-block h-3 w-3 rounded-sm bg-green-600" /> Answered</span>
                    <span className="flex items-center gap-1"><span className="inline-block h-3 w-3 rounded-sm bg-yellow-400" /> Flagged</span>
                </div>
                <div className="grid max-h-[8.5rem] grid-cols-5 justify-items-center gap-1.5 overflow-y-auto p-0.5">
                    {attempt.questions.map((question, index) => {
                        const isFlagged = flagged.has(question.id);
                        const color = isFlagged
                            ? 'bg-yellow-400 text-black'
                            : isAnswered(question)
                                ? 'bg-green-600 text-white'
                                : 'bg-black text-white';
                        const ring = activeId === question.id ? 'ring-2 ring-red-500 ring-offset-2 ring-offset-background' : '';
                        return (
                            <button
                                key={question.id}
                                type="button"
                                title={`Question ${index + 1}${question.type === 'ESSAY' ? ' (Essay)' : question.type === 'CODING' ? ' (Coding)' : ''}${isFlagged ? ' · Flagged' : ''}`}
                                aria-label={`Question ${index + 1}: ${isAnswered(question) ? 'Answered' : 'Unanswered'}${isFlagged ? ', Flagged' : ''}`}
                                aria-current={activeId === question.id ? 'true' : undefined}
                                onClick={() => jumpToQuestion(question)}
                                className={`flex h-7 w-7 items-center justify-center rounded-sm text-xs font-medium ${color} ${ring}`}
                            >
                                {index + 1}
                            </button>
                        );
                    })}
                </div>
                <div className="border-t pt-2">
                    <FontSizeControl font={questionFont} />
                </div>
            </div>
        </div>
    );

    const submitButton = (
        <Button onClick={() => void submitCurrentAnswers(true)} disabled={submitMutation.isPending}>
            {submitMutation.isPending ? 'Submitting...' : 'Submit Exam'}
        </Button>
    );

    if (!isFinished && currentCode) {
        return (
            <MainLayout
                pathName={{ exams: returnCrumbLabel, take: 'Take Exam' }}
                pathLinks={{ exams: returnTo }}
                focusMode
            >
                {timeUpOverlay}
{confirmOverlay}
                <CodingWorkspace
                    key={currentCode.id}
                    question={currentCode}
                    index={attempt.questions.indexOf(currentCode)}
                    value={currentAnswer?.textAnswer ?? null}
                    saved={currentSaved}
                    isSaving={isSaving}
                    hasSaveError={hasSaveError}
                    timerBox={timerBox}
                    notice={<ExamIntegrityNotice config={attempt.integrity} state={integrity} />}
                    onChange={(code) => updateAnswer(currentCode.id, { textAnswer: code })}
                    onSave={() => void saveEssay(currentCode.id)}
                    onBack={closeEssay}
                    onRetry={() => void flushPendingAnswers(attempt.id)}
                    onRun={(request) => runCode(attempt.id, request)}
                />
            </MainLayout>
        );
    }

    return (
        <MainLayout
            pathName={{ exams: returnCrumbLabel, take: 'Take Exam' }}
            pathLinks={{ exams: returnTo }}
            focusMode={!isFinished}
        >
            {timeUpOverlay}
{confirmOverlay}
            <main className="flex w-full flex-col gap-5">
                {!isFinished && pinnedBar}
                {!isFinished && <ExamIntegrityNotice config={attempt.integrity} state={integrity} />}
                {!isFinished && currentEssay && (
                    <EssayPopup
                        question={currentEssay}
                        index={currentEssayIndex}
                        value={currentAnswer?.textAnswer ?? ''}
                        saved={currentSaved}
                        isSaving={isSaving}
                        onChange={(value) => updateAnswer(currentEssay.id, { textAnswer: value })}
                        onSave={() => void saveEssay(currentEssay.id)}
                        onClose={closeEssay}
                    />
                )}
                {/* Timer + Questions Navigation noi tren noi dung; chua cho deu 2 ben de cau hoi luon nam giua. */}
                <div className="w-full lg:px-[12.5rem]">
                <div className="mx-auto flex w-full max-w-4xl flex-col gap-5">
                    <header className="flex flex-wrap items-start justify-between gap-4 border-b pb-4">
                        <div>
                            <p className="text-sm text-muted-foreground">Exam</p>
                            <h1 className="mt-1 text-2xl font-semibold">{attempt.title}</h1>
                            <p className="mt-2 text-sm text-muted-foreground">
                                Attempt #{attempt.attemptNumber} · Duration: {attempt.durationMinutes} mins · Max Score: {formatScore(attempt.maxScore ?? 10)}
                            </p>
                            <p className="mt-1 text-xs text-muted-foreground">
                                Official Deadline: {attempt.officialDeadlineAt
                                ? new Date(attempt.officialDeadlineAt).toLocaleString()
                                : 'Based on exam duration'}
                                {attempt.officialDeadlineAt && attempt.deadlineAt !== attempt.officialDeadlineAt
                                    ? ` · Extended Deadline: ${new Date(attempt.deadlineAt).toLocaleString()}`
                                    : ''}
                            </p>
                        </div>
                    </header>

                    {isFinished ? (
                        <section className="rounded-xl border p-6">
                            <h2 className="text-xl font-semibold">
                                {attempt.status === 'EXPIRED' && 'Time is up — Exam auto-submitted'}
                                {attempt.status === 'PENDING_REVIEW' && 'Submitted — Pending essay review'}
                                {attempt.status === 'SUBMITTED' && 'Exam Completed'}
                            </h2>
                            {isResultPublished ? (
                                <>
                                    <p className="mt-3 text-lg">
                                        {attempt.finalScore == null
                                            ? `Provisional Score: ${formatScore(attempt.provisionalScore ?? attempt.objectiveScore ?? 0)}/${formatScore(attempt.maxScore ?? 10)} (essay and coding answers that are still being graded count as 0)`
                                            : `Score: ${formatScore(attempt.finalScore)}/${formatScore(attempt.maxScore ?? 10)}`}
                                    </p>
                                    {attempt.status === 'EXPIRED' && (
                                        <p className="mt-2 text-sm text-muted-foreground">
                                            Exam time has ended. Only answers provided before the deadline were graded.
                                        </p>
                                    )}
                                    {attempt.bestScore != null && (
                                        <p className="mt-2 text-sm font-medium text-emerald-700">
                                            Highest Score: {formatScore(attempt.bestScore)}/{formatScore(attempt.maxScore ?? 10)}
                                        </p>
                                    )}
                                </>
                            ) : (
                                <p className="mt-3 text-lg text-amber-700">
                                    Awaiting publication — your teacher has not released the results yet.
                                </p>
                            )}
                            {attempt.late && (
                                <p className="mt-2 text-sm text-amber-700">
                                    Submitted during extended deadline.
                                    {attempt.latePenaltyPercentApplied != null
                                        ? ` Applied penalty: -${attempt.latePenaltyPercentApplied}%.`
                                        : ''}
                                </p>
                            )}
                            {isResultPublished && attempt.finalScore === null && attempt.status !== 'SUBMITTED' && (
                                <p className="mt-2 text-sm text-muted-foreground">
                                    Final score will be updated once grading is finished: coding answers are graded automatically within a few minutes, and essay answers are graded by your teacher.
                                </p>
                            )}
                            <Button className="mt-5 mr-2" variant="outline" onClick={() => navigate(assessmentPreparationPath(examId, returnTo))}>Assessment overview</Button>
                            <Button className="mt-5" variant="outline" onClick={() => navigate(returnTo)}>
                                {returnLabel}
                            </Button>
                        </section>
                    ) : (
                        <>
                            {codingQuestions.length > 0 && (
                                <section className="rounded-xl border p-4">
                                    <h2 className="mb-3 font-semibold">Coding Questions</h2>
                                    <div className="grid grid-cols-[minmax(0,1fr)] gap-2">
                                        {codingQuestions.map((question) => {
                                            const saved = Boolean(answers[question.id]?.saved);
                                            return (
                                                <div key={question.id} className="flex min-w-0 items-center justify-between gap-3 rounded-md border p-3">
                                                    <div className="min-w-0">
                                                        <p className="text-sm font-medium">
                                                            Question {attempt.questions.indexOf(question) + 1}
                                                            <span className="ml-2 font-normal text-muted-foreground">{formatScore(questionScore(attempt.maxScore, question.points, attempt.totalPoints))} pts</span>
                                                        </p>
                                                        <p className="truncate text-sm text-muted-foreground">{question.content}</p>
                                                    </div>
                                                    <div className="flex shrink-0 items-center gap-3">
                                                        {starButton(question.id, attempt.questions.indexOf(question) + 1)}
                                                        {saved && <span className="text-sm font-medium text-green-600">Saved</span>}
                                                        {!saved && hasText(question.id) && <span className="text-sm text-muted-foreground">Drafting</span>}
                                                        <Button
                                                            size="sm"
                                                            className={saved ? 'bg-green-600 text-white hover:bg-green-700' : 'bg-blue-600 text-white hover:bg-blue-700'}
                                                            onClick={() => openCode(question.id)}
                                                        >
                                                            {saved ? 'Edit Answer' : hasText(question.id) ? 'Continue' : 'Start Answer'}
                                                        </Button>
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                </section>
                            )}

                            {!isOnline && (
                                <div
                                    role="status"
                                    className="sticky top-2 z-30 flex items-center gap-2 rounded-lg border border-amber-400 bg-amber-50 px-4 py-3 text-sm text-amber-900 shadow-sm"
                                >
                                    <WifiOff className="size-4 shrink-0" />
                                    You are offline. Keep answering: your answers are kept on this device and are sent automatically when the connection returns. Do not close this tab.
                                </div>
                            )}

                            <div className="flex flex-wrap items-center justify-between gap-3 text-sm text-muted-foreground">
                                <span>Your answers are automatically saved as you make changes.</span>

                                {isSaving && <span>Saving...</span>}

                                {hasSaveError && (
                                    <span role="alert" className="text-destructive">
                                        Connection problem: some answers have not reached the server. A copy is kept on this device and is sent automatically when the connection returns.
                                        <Button
                                            variant="outline"
                                            size="sm"
                                            onClick={() => void flushPendingAnswers(attempt.id)}
                                        >
                                            Retry Saving
                                        </Button>
                                    </span>
                                )}
                            </div>

                            {attempt.questions.map((question, index) => {
                                if (question.type === 'CODING') return null;
                                const answer = answers[question.id] ?? {
                                    questionId: question.id,
                                    selectedOptionIds: [],
                                    textAnswer: null,
                                };

                                return (
                                    <section
                                        key={question.id}
                                        id={`question-card-${question.id}`}
                                        className={`rounded-xl border p-5 transition-all ${
                                            activeId === question.id ? 'ring-2 ring-red-500' : ''
                                        }`}
                                    >
                                        <div className="flex items-center justify-between gap-2">
                                            <h2 className="font-semibold">
                                                Question {index + 1}
                                                <span className="ml-2 text-sm font-normal text-muted-foreground">
                                                    {formatScore(questionScore(attempt.maxScore, question.points, attempt.totalPoints))} pts
                                                </span>
                                            </h2>
                                            {starButton(question.id, index + 1)}
                                        </div>

                                        <p className="mt-3 whitespace-pre-wrap" style={questionFont.style}>{question.content}</p>

                                        {question.imageUrl?.trim() && (
                                            <div className="mt-3">
                                                <img
                                                    src={question.imageUrl}
                                                    alt={`Question ${index + 1} image`}
                                                    className="max-h-64 rounded-md border object-contain shadow-sm"
                                                />
                                            </div>
                                        )}

                                        {question.type === 'ESSAY' ? (
                                            <div
                                                role="button"
                                                tabIndex={0}
                                                onClick={() => openEssay(question.id)}
                                                onKeyDown={(event) => {
                                                    if (event.key === 'Enter' || event.key === ' ') {
                                                        event.preventDefault();
                                                        openEssay(question.id);
                                                    }
                                                }}
                                                className={`mt-4 flex min-h-[3.5rem] cursor-pointer items-center justify-between gap-3 rounded-lg border p-3 transition hover:bg-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
                                                    answer.saved ? 'border-green-600/60 bg-green-600/5' : 'bg-muted/30'
                                                }`}
                                            >
                                                <span className="min-w-0 truncate text-sm text-muted-foreground">
                                                    {hasText(question.id)
                                                        ? (answer.textAnswer ?? '').trim()
                                                        : 'Click here to write your answer'}
                                                </span>
                                                <span className={`shrink-0 text-xs font-medium ${answer.saved ? 'text-green-600' : 'text-muted-foreground'}`}>
                                                    {answer.saved ? 'Saved' : hasText(question.id) ? 'Draft' : ''}
                                                </span>
                                            </div>
                                        ) : (
                                            <div className="mt-4 grid gap-3">
                                                {question.options.map((option) => {
                                                    const checked = answer.selectedOptionIds.includes(option.id);
                                                    const isMulti = question.multiSelect;
                                                    const inputType = isMulti ? 'checkbox' : 'radio';
                                                    return (
                                                        <label
                                                            key={option.id}
                                                            className="flex cursor-pointer items-start gap-3 rounded-md border p-3 hover:bg-muted/50"
                                                        >
                                                            <input
                                                                type={inputType}
                                                                name={`question-${question.id}`}
                                                                checked={checked}
                                                                onChange={() => {
                                                                    const selectedOptionIds = !isMulti
                                                                        ? [option.id]
                                                                        : checked
                                                                            ? answer.selectedOptionIds.filter((id) => id !== option.id)
                                                                            : [...answer.selectedOptionIds, option.id];
                                                                    updateAnswer(question.id, { selectedOptionIds });
                                                                }}
                                                                disabled={isFinished}
                                                                className="mt-1"
                                                            />
                                                            <div className="flex flex-col gap-2">
                                                                <span style={questionFont.style}>{option.content}</span>
                                                                {option.imageUrl?.trim() && (
                                                                    <img
                                                                        src={option.imageUrl}
                                                                        alt=""
                                                                        className="max-h-40 rounded border object-contain"
                                                                    />
                                                                )}
                                                            </div>
                                                        </label>
                                                    );
                                                })}
                                            </div>
                                        )}
                                    </section>
                                );
                            })}

                            {/* CHANGED: da bo nut "Leave Exam" */}
                            <footer className="flex flex-wrap justify-end gap-3 border-t pt-4">
                                {submitButton}
                            </footer>
                        </>
                    )}
                </div>
                </div>
            </main>
        </MainLayout>
    );
}
