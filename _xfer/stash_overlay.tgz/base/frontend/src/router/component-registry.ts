import NotificationCenterPage from "@/pages/notifications/NotificationCenterPage";
import RecommendedCoursesPage from "@/pages/student/RecommendedCoursesPage";
import CourseLearnerGradesPage from "@/pages/management/demo/course/pages/CourseLearnerGradesPage";
import ScoreManagementPage from "@/pages/management/exam/score-management";
import ExamCurriculumPage from "@/pages/management/exam/curriculum/ExamCurriculumPage";
import WeeklyCalendarPage from "@/pages/management/calendar/WeeklyCalendarPage";
import ScheduleVersionListPage from "@/pages/management/demo/schedule_version";
import AuditPage from "@/pages/management/training/audit";
import TraineePage from "@/pages/management/training/trainee";
import LogWorkPage from "@/pages/management/training/log-work";
import TopicManagementPage from "@/pages/management/training/topic/TopicManagementPage";
import ProgramManagementPage from "@/pages/management/training/program/ProgramManagementPage";
import ReportsPage from "@/pages/management/training/reports";
import ClassListPage from "@/pages/management/training/class/ClassListPage";
import ClassDetailPage from "@/pages/management/training/class/ClassDetailPage";
import ClassSetupPage from "@/pages/management/training/class/ClassSetupPage";
import SessionDetailPage from "@/pages/management/demo/session/SessionDetailPage";
import SessionManagementPage from "@/pages/management/demo/session/SessionManagementPage";
import { Logout } from "@/components/auth/Logout";
import { OAuth2RedirectHandler } from "@/components/auth/OAuth2RedirectHandler";
import ForgotPasswordPage from "@/pages/auth/ForgotPasswordPage";
import { Login } from "@/pages/auth/Login";
import RegisterPage from "@/pages/auth/RegisterPage";
import NotFoundPage from "@/pages/error/NotFoundPage";
import { Unauthorized } from "@/pages/error/Unauthorized";
import ProjectBoardPage from "@/pages/project/ProjectBoardPage";
import BacklogPage from "@/pages/management/backlog";
import { Dashboard } from "@/pages/management/dashboard";
import CurriculumManagementPage from "@/pages/management/demo/curriculum";
import RolePermissionMatrixPage from "@/pages/management/rbac/permission/RolePermissionMatrixPage";
import ExamManagementPage from "@/pages/management/exam";
import ExamDetailPage from "@/pages/management/exam/ExamDetailPage";
import ExamTemplatesPage from "@/pages/management/exam/templates";
import EssayAttemptDetailPage from "@/pages/management/exam/grading/EssayAttemptDetailPage";
import ExamSimilarityPage from "@/pages/management/exam/similarity/ExamSimilarityPage";
import ScoreAppealsPage from "@/pages/management/exam/appeals";
import UnifiedInvitationsPage, {
  StudentInvitationsRedirect,
} from "@/pages/invitations/InvitationsPage";
import TopicMarkGradebookDemoPage from "@/pages/management/demo/topic_mark_gradebook";
import TeamAllocationPage from "@/pages/management/team-allocation";
import TeamAllocationSetupPage from "@/pages/management/team-allocation/setup";
import TeamAllocationClassListPage from "@/pages/management/team-allocation/class-list";
import ProjectAssignmentPage from "@/pages/management/team-allocation/ProjectAssignmentPage";
import StudentExamList from "@/pages/student/StudentExamList";
import StudentExamPreparationPage from "@/pages/student/StudentExamPreparationPage";
import StudentExamTakingPage from "@/pages/student/StudentExamTakingPage";
import StudentLandingPage from "@/pages/student/StudentLandingPage";
import ExploreProjectsPage from "@/pages/student/projects/explore";
import StudentProjectDetailPage from "@/pages/student/projects/detail";
import StudentDraftTeamPage from "@/pages/student/draft-team";
import ProjectTemplateVersionPage from "@/pages/management/project-template-version";
import TeacherLandingPage from "@/pages/teacher/TeacherLandingPage";
import { MilestoneCreatePage } from "@/pages/management/project/milestone/pages/MilestoneCreatePage";
import { MilestoneDetailPage } from "@/pages/management/project/milestone/pages/MilestoneDetailPage";
import { MilestoneListPage } from "@/pages/management/project/milestone/pages/MilestoneListPage";
import { MilestoneEntryPage } from "@/pages/management/project/milestone/pages/MilestoneEntryPage";
import { TeamMilestoneDetailPage } from "@/pages/management/project/milestone/pages/TeamMilestoneDetailPage";
import TeamArtifactSubmissionPage from "@/pages/student/TeamArtifactSubmissionPage";
import TeamMilestoneSubmissionsPage from "@/pages/management/project/milestone/pages/TeamMilestoneSubmissionsPage";
import { RubricListPage } from "@/pages/management/project/rubric/pages/RubricListPage";
import { RubricCreatePage } from "@/pages/management/project/rubric/pages/RubricCreatePage";
import { RubricDetailPage } from "@/pages/management/project/rubric/pages/RubricDetailPage";
import { RubricEditPage } from "@/pages/management/project/rubric/pages/RubricEditPage";
import { SubmissionListPage } from "@/pages/management/project/milestone-submission/pages/SubmissionListPage";
import { SubmissionReviewPage } from "@/pages/management/project/milestone-submission/pages/SubmissionReviewPage";
import { StudentSubmissionPage } from "@/pages/student/milestone-submission/StudentSubmissionPage";
import { StudentSubmissionListPage } from "@/pages/student/milestone-submission/StudentSubmissionListPage";
import WorkspaceCandidatePage from "@/pages/management/workspace/WorkspaceCandidatePage";
import WorkspaceDetailPage from "@/pages/management/workspace/WorkspaceDetailPage";
import { createElement } from "react";
import TaskManagementPage from "@/pages/management/task";
import ProjectAlertsPage from "@/pages/management/alerts";
import ProjectReportsPage from "@/pages/management/project-reports";
import ProjectTemplateListPage from "@/pages/management/project-template";
import ExamSupervisorPage from "@/pages/management/exam/supervisor";
import { ProjectTemplateFormPage } from "@/pages/management/project-template/pages/ProjectTemplateFormPage";
import { ProjectTemplateDetailPage } from "@/pages/management/project-template/pages/ProjectTemplateDetailPage";
import ArtifactDraftPage from "@/pages/student/ArtifactDraftPage";
import StudentTeamMilestoneSubmissionsPage from "@/pages/student/StudentTeamMilestoneSubmissionsPage";
import MyScoresPage from "@/pages/student/MyScoresPage";
import MyAppealsPage from "@/pages/student/MyAppealsPage";
import ExamReviewPage from "@/pages/student/ExamReviewPage";
import PeerReviewListPage from "@/pages/student/PeerReviewListPage";
import PeerReviewFormPage from "@/pages/student/PeerReviewFormPage";
import PeerReviewFeedbackPage from "@/pages/student/PeerReviewFeedbackPage";
import PeerReviewOverviewPage from "@/pages/management/exam/reviews/PeerReviewOverviewPage";
import AnonymousAccessPage from "@/pages/exam/AnonymousAccessPage";
import AnonymousExamTakingPage from "@/pages/exam/AnonymousExamTakingPage";
import { ModuleGroupModulePage } from "@/pages/management/fams/ModuleGroupModulePage";
import type { ComponentType } from "react";
import { buildEntityRoutes } from "./build-router";
import TrainerManagementPage from "@/pages/management/training/trainer/TrainerManagementPage";
import { Navigate } from "react-router-dom";

import SyllabusesPage from "@/pages/management/demo/syllabus";
import SyllabusDetailPage from "@/pages/management/demo/syllabus/detail";
import CreateCourseFromSyllabusPage from "@/pages/management/demo/syllabus/CreateCourseFromSyllabusPage";
import SyllabusCourseWorkspacePage from "@/pages/management/demo/syllabus/SyllabusCourseWorkspacePage";
import CourseUsagePage from "@/pages/management/demo/syllabus/CourseUsagePage";
import SyllabusTemplatesPage from "@/pages/management/demo/syllabus/SyllabusTemplatesPage";

import StudentSyllabusListPage from "@/pages/student/StudentSyllabusListPage";
import StudentSyllabusPage from "@/pages/student/StudentSyllabusPage";

import CourseReportPage from "@/pages/management/demo/report";
import StudentAnalyticsPage from "@/pages/management/analytics/StudentAnalyticsPage";
import CourseAnalyticsPage from "@/pages/management/demo/analytics";
import { CourseEnrollmentDetailPage } from "@/pages/management/demo/course/pages/CourseEnrollmentDetailPage";
import UnansweredQuestionsPage from "@/pages/management/demo/unanswered-questions";
import LessonReportsPage from "@/pages/management/demo/lesson-reports";
import CertificateDetailPage from "@/pages/management/demo/certificate/pages/CertificateDetailPage";
import VerifyCertificatePage from "@/pages/student/VerifyCertificatePage";
import EnrollmentLogPage from "@/pages/management/demo/enrollment/EnrollmentLogPage.tsx";
import DepartmentManagementPage from "@/pages/management/demo/department";
import CourseGradeDetailPage from "@/pages/student/CourseGradeDetailPage";

export interface RouteConfig {
  path: string;
  component: ComponentType<any>;
  requiredPermission?: string;
  requiredPermissions?: string[];
  isPublic?: boolean;
  isModuleDriven?: boolean;
}

export const ROLE_HOME_PATHS = [
  "/dashboard",
  "/student",
  "/teacher",
] as const;

export const routes: RouteConfig[] = [
  { path: "/trainers", component: TrainerManagementPage, requiredPermission: "TRAINER_READ" },
  // TRAINING OPERATIONS & LMS
  { path: "/training/audit", component: AuditPage, isModuleDriven: true },
  { path: "/training/trainee", component: TraineePage, isModuleDriven: true },
  { path: "/training/log-work", component: LogWorkPage, isModuleDriven: true },
  { path: "/training/content", component: TopicManagementPage, isModuleDriven: true },
  { path: "/subjects", component: TopicManagementPage, requiredPermission: "SUBJECT_READ", isModuleDriven: true },
  { path: "/topics", component: TopicManagementPage, requiredPermission: "SUBJECT_READ" },
  { path: "/training/topics", component: TopicManagementPage, requiredPermission: "SUBJECT_READ" },
  { path: "/programs", component: ProgramManagementPage, requiredPermission: "PROGRAM_READ", isModuleDriven: true },
  { path: "/training/programs", component: ProgramManagementPage, requiredPermission: "PROGRAM_READ" },
  { path: "/class-setup", component: ClassSetupPage, requiredPermission: "CLASS_READ", isModuleDriven: true },
  { path: "/training/reports", component: ReportsPage, isModuleDriven: true },
  { path: "/classes", component: ClassListPage, requiredPermission: "SESSION_READ", isModuleDriven: true },
  { path: "/classes/:classId", component: ClassDetailPage, requiredPermission: "SESSION_READ" },
  { path: "/training-operations/class-details/:classCode", component: ClassDetailPage, requiredPermission: "SESSION_READ" },
  { path: "/class-details/:classId", component: ClassDetailPage, requiredPermission: "SESSION_READ" },
  { path: "/sessions/:sessionId", component: SessionDetailPage, requiredPermission: "SESSION_READ" },
  { path: "/sessions", component: SessionManagementPage, requiredPermission: "SESSION_READ" },
  { path: "/calendar/preview", component: WeeklyCalendarPage, requiredPermission: "SESSION_READ", isModuleDriven: true },
  { path: "/schedule-versions", component: ScheduleVersionListPage, requiredPermission: "SESSION_READ", isModuleDriven: true },
  { path: "/calendar/adjust", component: ScheduleVersionListPage, requiredPermission: "SESSION_READ", isModuleDriven: true },
  { path: "/courses/:id/grades", component: CourseLearnerGradesPage, requiredPermissions: ["COURSE_REPORT_READ", "EXAM_READ"] },
  { path: "/tasks", component: TaskManagementPage, requiredPermission: "TASK_READ" },
  { path: "/management/alerts", component: ProjectAlertsPage, requiredPermission: "PROJECT_ALERT_READ" },
  { path: "/management/reports/projects", component: ProjectReportsPage, requiredPermission: "PROJECT_REPORT_READ" },
  { path: "/tasks/create", component: TaskManagementPage, requiredPermission: "TASK_CREATE" },
  { path: "/tasks/:id/edit", component: TaskManagementPage, requiredPermission: "TASK_UPDATE" },
  { path: "/tasks/:id/detail", component: TaskManagementPage, requiredPermission: "TASK_READ" },
  { path: "/project-templates", component: ProjectTemplateListPage, requiredPermission: "PROJECT_TEMPLATE_READ" },
  { path: "/project-template-versions", component: ProjectTemplateVersionPage, requiredPermission: "PROJECT_TEMPLATE_READ" },
  { path: "/project-templates/create", component: ProjectTemplateFormPage, requiredPermission: "PROJECT_TEMPLATE_CREATE" },
  { path: "/project-templates/:id/edit", component: ProjectTemplateFormPage, requiredPermission: "PROJECT_TEMPLATE_UPDATE" },
  { path: "/project-templates/:id/detail", component: ProjectTemplateDetailPage, requiredPermission: "PROJECT_TEMPLATE_READ" },

  // FAMS MODULE GROUP MODULE
  {
    path: "/fams/module-group-module",
    component: ModuleGroupModulePage,
    isPublic: true,
  },
  {
    path: "/module-group-module",
    component: ModuleGroupModulePage,
    isPublic: true,
  },

  // ROLE HOME
  {
    path: "/dashboard",
    component: Dashboard,
  },
  {
    path: "/student",
    component: StudentLandingPage,
  },
  {
    path: "/teacher",
    component: TeacherLandingPage,
  },

  // DASHBOARD
  {
    path: "/dashboard",
    component: Dashboard,
    isModuleDriven: true,
  },

  // RBAC
  {
    path: "/role-permissions",
    component: RolePermissionMatrixPage,
    requiredPermission: "ROLE_UPDATE",
  },

  // EXAMS
  {
    path: "/exams/score-management",
    component: ScoreManagementPage,
    requiredPermission: "EXAM_UPDATE",
  },
  {
    path: "/exams/curriculum",
    component: ExamCurriculumPage,
    requiredPermission: "EXAM_UPDATE",
  },
  {
    path: "/exams",
    component: ExamManagementPage,
    isModuleDriven: true,
    requiredPermission: "EXAM_UPDATE",
  },

  {
    path: "/exams/supervisor",
    component: ExamSupervisorPage,
    requiredPermission: "EXAM_UPDATE",
  },

  {
    path: "/management/exam/templates",
    component: ExamTemplatesPage,
    requiredPermission: "EXAM_UPDATE",
  },

  // INVITATIONS
  {
    path: "/invitations",
    component: UnifiedInvitationsPage,
    requiredPermission: "INVITATION_READ",
  },

  // One page per exam with 5 tabs: Edit, Questions, Grading, Invitations, Statistics.
  {
    path: "/exams/:examId",
    component: ExamDetailPage,
    requiredPermission: "EXAM_UPDATE",
  },
  {
    path: "/exams/:examId/questions",
    component: ExamDetailPage,
    requiredPermission: "EXAM_UPDATE",
  },
  {
    path: "/exams/:examId/edit",
    component: ExamDetailPage,
    requiredPermission: "EXAM_UPDATE",
  },
  {
    path: "/exams/:examId/grading",
    component: ExamDetailPage,
    requiredPermission: "EXAM_UPDATE",
  },
  {
    path: "/exams/:examId/invitations",
    component: ExamDetailPage,
    requiredPermission: "INVITATION_READ",
  },
  {
    path: "/exams/:examId/result-statistics",
    component: ExamDetailPage,
    requiredPermission: "EXAM_UPDATE",
  },

  {
    path: "/exams/:examId/similarity",
    component: ExamSimilarityPage,
    requiredPermission: "EXAM_UPDATE",
  },
  {
    path: "/exams/:examId/grading/similarity",
    component: ExamSimilarityPage,
    requiredPermission: "EXAM_UPDATE",
  },

  {
    path: "/exams/:examId/grading/:attemptId",
    component: EssayAttemptDetailPage,
    requiredPermission: "EXAM_UPDATE",
  },

  // SCORE APPEALS
  {
    path: "/exams/appeals",
    component: ScoreAppealsPage,
    requiredPermission: "SCORE_APPEAL_READ",
  },

  // ANONYMOUS EXAM ACCESS
  {
    path: "/anonymous-exam",
    component: AnonymousAccessPage,
    isPublic: true,
  },
  {
    path: "/anonymous-exam/take",
    component: AnonymousExamTakingPage,
    isPublic: true,
  },

  // STUDENT INVITATIONS
  {
    path: "/student/invitations",
    component: StudentInvitationsRedirect,
    requiredPermission: "INVITATION_READ",
  },

  // TOPIC MARKS
  {
    // Student backlog view (also served at /sprints for non-admin roles).
    path: "/backlogs",
    component: BacklogPage,
    requiredPermission: "SPRINT_READ",
    isModuleDriven: false,
  },
  {
    path: "/topic-marks",
    component: TopicMarkGradebookDemoPage,
    requiredPermission: "SESSION_READ",
    isModuleDriven: false,
  },
  {
    path: "/topic-marks/gradebook-demo",
    component: TopicMarkGradebookDemoPage,
    requiredPermission: "STUDENT_SCORE_READ",
    isModuleDriven: true,
  },

  // M3 ADMIN / TEACHER
  {
    path: "/syllabuses",
    component: SyllabusesPage,
    requiredPermission: "SYLLABUS_READ",
    isModuleDriven: true,
  },
  {
    path: "/syllabuses/:id/workspace",
    component: SyllabusCourseWorkspacePage,
    requiredPermission: "SYLLABUS_READ",
    isModuleDriven: false,
  },
  {
    path: "/syllabuses/:id/create-course",
    component: CreateCourseFromSyllabusPage,
    // The page and Backend also require all four authorities, not any single authority.
    requiredPermission: "SYLLABUS_READ",
    isModuleDriven: false,
  },
  {
    path: "/syllabuses/:id",
    component: SyllabusDetailPage,
    requiredPermission: "SYLLABUS_READ",
    isModuleDriven: false,
  },

  {
    path: "/team-allocation",
    component: TeamAllocationClassListPage,
    requiredPermission: "PEO_TEAM_ALLOCATE",
    isModuleDriven: true,
  },
  {
    path: "/team-allocation/classes/:classId",
    component: TeamAllocationPage,
    requiredPermissions: ["PEO_TEAM_ALLOCATE", "PRJ_WORKSPACE_MANAGE"],
  },
  {
    // Allocation workspace of one session: "Allocate Teams" + "Set up Teams".
    path: "/team-allocation/classes/:classId/setup",
    component: TeamAllocationSetupPage,
    requiredPermissions: ["PEO_TEAM_ALLOCATE", "PRJ_WORKSPACE_MANAGE"],
  },
  {
    path: "/team-allocation/classes/:classId/assign",
    component: ProjectAssignmentPage,
    requiredPermissions: ["PEO_TEAM_ALLOCATE", "PRJ_WORKSPACE_MANAGE"],
  },
  {
    // US-09: mock Project Template catalogue (Project Management tab).
    // Module-driven: `useSidebarMenus` injects the matching student module
    // entry, and `App` resolves it through the module-driven component map.
    // Without `isModuleDriven`, the injected module route would shadow this
    // route with a "missing component" redirect (page not found).
    // No permission string because the Project Template module is not seeded
    // yet; access is limited to authenticated users, and the data scope is
    // mocked in `mocks/project-templates.mock.ts`.
    path: "/student/projects/explore",
    component: ExploreProjectsPage,
    isModuleDriven: true,
  },
  {
    // US-09 / AC02: full project brief on its own page (no modal).
    // Reached from a catalogue card on `/student/projects/explore`.
    path: "/student/projects/detail/:projectId",
    component: StudentProjectDetailPage,
  },
  {
    // US-10: the student (team leader) screen that assigns a project template
    // to the DRAFT teams they lead. Authenticated users only; the backend
    // enforces ownership (team role PM) and the capacity window.
    path: "/student/draft-team",
    component: StudentDraftTeamPage,
    isModuleDriven: true,
  },
  { path: "/project-board", component: ProjectBoardPage },
  { path: "/workspaces/candidates", component: WorkspaceCandidatePage, requiredPermission: "WORKSPACE_READ" },
  { path: "/management/workspaces", component: WorkspaceCandidatePage, requiredPermission: "WORKSPACE_READ" },
  { path: "/management/workspaces/candidates", component: WorkspaceCandidatePage, requiredPermission: "WORKSPACE_READ" },
  { path: "/management/workspaces/:id", component: WorkspaceDetailPage, requiredPermission: "WORKSPACE_READ" },
  { path: "/management/project-teams", component: () => createElement(Navigate, { to: "/management/workspaces/candidates", replace: true }), requiredPermission: "WORKSPACE_READ" },
  { path: "/milestones", component: MilestoneListPage, requiredPermission: "MILESTONE_READ" },
  { path: "/milestones/teams", component: MilestoneEntryPage, requiredPermission: "MILESTONE_READ" },
  { path: "/projects/:projectId/milestones", component: MilestoneListPage, requiredPermission: "MILESTONE_READ" },
  { path: "/teams/:teamId/milestones/new", component: MilestoneCreatePage, requiredPermission: "MILESTONE_WRITE" },
  { path: "/teams/:teamId/milestones/:milestoneId/edit", component: MilestoneCreatePage, requiredPermission: "MILESTONE_WRITE" },
  { path: "/teams/:teamId/milestones/:milestoneId", component: TeamMilestoneDetailPage, requiredPermission: "MILESTONE_READ" },
  { path: "/teams/:teamId/milestones/:milestoneId/submit", component: TeamArtifactSubmissionPage, requiredPermission: "ARTIFACT_READ" },
  { path: "/teams/:teamId/milestones/:milestoneId/submissions", component: TeamMilestoneSubmissionsPage },
  { path: "/student/teams/:teamId/milestones/:milestoneId/submissions", component: StudentTeamMilestoneSubmissionsPage, requiredPermission: "ARTIFACT_READ" },
  {
    path: "/projects/:projectId/milestones/new",
    component: MilestoneCreatePage,
  },
  { path: "/projects/:projectId/milestones/:milestoneId/edit", component: MilestoneCreatePage, requiredPermission: "MILESTONE_WRITE" },
  {
    path: "/projects/:projectId/milestones/:milestoneId",
    component: MilestoneDetailPage,
  },
  {
    path: "/projects/:projectId/milestones/:milestoneId/submit",
    component: ArtifactDraftPage,
    requiredPermission: "ARTIFACT_READ",
  },
  { path: "/rubrics", component: RubricListPage },
  { path: "/rubrics/new", component: RubricCreatePage },
  { path: "/rubrics/:rubricId", component: RubricDetailPage },
  { path: "/rubrics/:rubricId/versions/:versionId/edit", component: RubricEditPage },
  { path: "/milestone-submissions", component: SubmissionListPage },
  { path: "/milestone-submissions/:submissionId/review", component: SubmissionReviewPage },
  { path: "/milestone-submissions/:submissionId", component: SubmissionReviewPage },
  { path: "/student/milestone-submissions", component: StudentSubmissionListPage },
  { path: "/student/milestone-submissions/:submissionId", component: StudentSubmissionPage },
  { path: "/student/milestone-submissions/:submissionId/edit", component: StudentSubmissionPage },
  {
    path: "/syllabuses/course-usage",
    component: CourseUsagePage,
    requiredPermission: "SYLLABUS_READ",
    isModuleDriven: true,
  },
  {
    path: "/syllabuses/templates",
    component: SyllabusTemplatesPage,
    requiredPermission: "SYLLABUS_CREATE",
    isModuleDriven: true,
  },
  // M3 STUDENT VIEW
  {
    path: "/student/syllabuses",
    component: StudentSyllabusListPage,
    requiredPermission: "COURSE_READ",
    isModuleDriven: false,
  },
  {
    path: "/student/syllabuses/:id",
    component: StudentSyllabusPage,
    requiredPermission: "COURSE_READ",
    isModuleDriven: false,
  },

  // CERTIFICATES
  {
    path: "/my-certificates/:verificationToken",
    component: CertificateDetailPage,
    isModuleDriven: false,
  },
  {
    path: "/verify-certificate/:verificationToken",
    component: VerifyCertificatePage,
    isPublic: true,
    isModuleDriven: false,
  },

  { path: "/notifications", component: NotificationCenterPage, isModuleDriven: false },
  { path: "/student/recommendations", component: RecommendedCoursesPage, requiredPermission: "ENROLLMENT_CREATE", isModuleDriven: false },
  // STUDENT
  {
    path: "/student",
    component: StudentLandingPage,
    requiredPermission: "BOOK_READ",
  },
  {
    path: "/student/exams",
    component: StudentExamList,
    requiredPermission: "EXAM_READ",
    isModuleDriven: true,
  },

  {
    path: "/student/exams/:examId/prepare",
    component: StudentExamPreparationPage,
    requiredPermission: "EXAM_TAKE",
  },

  {
    path: "/student/exams/:examId/take",
    component: StudentExamTakingPage,
    requiredPermission: "EXAM_TAKE",
  },

  {
    path: "/student/exams/attempts/:attemptId/review",
    component: ExamReviewPage,
    requiredPermission: "EXAM_TAKE",
  },

  // PEER / SELF REVIEW (UFR-EXM-012)
  {
    path: "/student/reviews",
    component: PeerReviewListPage,
    requiredPermission: "EXAM_REVIEW_READ",
    isModuleDriven: false,
  },

  {
    path: "/student/reviews/:assignmentId",
    component: PeerReviewFormPage,
    requiredPermission: "EXAM_REVIEW_READ",
    isModuleDriven: false,
  },

  {
    path: "/student/feedback",
    component: PeerReviewFeedbackPage,
    requiredPermission: "EXAM_REVIEW_READ",
    isModuleDriven: false,
  },

  {
    path: "/exams/:examId/reviews",
    component: PeerReviewOverviewPage,
    requiredPermission: "EXAM_REVIEW_VIEW_ALL",
    isModuleDriven: false,
  },

  // MY SCORES / MY APPEALS
  {
    path: "/my-scores",
    component: MyScoresPage,
    requiredPermission: "STUDENT_SCORE_VIEW_OWN",
    isModuleDriven: true,
  },

  {
    path: "/my-scores/:courseId",
    component: CourseGradeDetailPage,
    requiredPermission: "STUDENT_SCORE_VIEW_OWN",
    isModuleDriven: false,
  },

  {
    path: "/my-appeals",
    component: MyAppealsPage,
    requiredPermission: "SCORE_APPEAL_VIEW_OWN",
  },

  // TEACHER
  {
    path: "/teacher",
    component: TeacherLandingPage,
    requiredPermission: "BOOK_UPDATE",
  },

  // DYNAMIC ENTITY ROUTES
  ...buildEntityRoutes(),

  // AUTHENTICATION
  {
    path: "/not-found-page",
    component: NotFoundPage,
    isPublic: true,
  },
  {
    path: "/login",
    component: Login,
    isPublic: true,
  },
  {
    path: "/logout",
    component: Logout,
    isPublic: true,
  },
  {
    path: "/register",
    component: RegisterPage,
    isPublic: true,
  },
  {
    path: "/forgot-password",
    component: ForgotPasswordPage,
    isPublic: true,
  },
  {
    path: "/oauth2/redirect",
    component: OAuth2RedirectHandler,
    isPublic: true,
  },
  {
    path: "/unauthorized",
    component: Unauthorized,
    isPublic: true,
  },

  // CURRICULUM
  {
    path: "/curriculum",
    component: CurriculumManagementPage,
    requiredPermission: "SECTION_READ",
    isModuleDriven: true,
  },

  // COURSE REPORT
  {
    path: "/analytics/students",
    component: StudentAnalyticsPage,
    requiredPermission: "STUDENT_ANALYTICS_READ",
    isModuleDriven: true,
  },
  {
    path: "/course-enrollments",
    component: CourseReportPage,
    requiredPermission: "COURSE_REPORT_READ",
    isModuleDriven: true,
  },
  {
    path: "/course-analytics",
    component: CourseAnalyticsPage,
    requiredPermission: "COURSE_REPORT_READ",
    isModuleDriven: true,
  },
  {
    path: "/course-enrollments/:id",
    component: CourseEnrollmentDetailPage,
    requiredPermission: "COURSE_REPORT_READ",
    isModuleDriven: false,
  },

  // Q&A
  {
    path: "/unanswered-questions",
    component: UnansweredQuestionsPage,
    requiredPermission: "LESSON_ANSWER_CREATE",
    isModuleDriven: true,
  },

  // LESSON REPORTS
  {
    path: "/lesson-reports",
    component: LessonReportsPage,
    requiredPermission: "LESSON_REPORT_READ",
    isModuleDriven: true,
  },

  // ENROLLMENT LOGS
  {
    path: "/enrollment-logs",
    component: EnrollmentLogPage,
    isModuleDriven: true,
  },

  // MANAGE STUDENT
  {
    path: "/manage-students",
    component: DepartmentManagementPage,
    requiredPermission: "DEPARTMENT_READ",
    isModuleDriven: true,
  },
];
