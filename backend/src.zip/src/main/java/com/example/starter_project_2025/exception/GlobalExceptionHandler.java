package com.example.starter_project_2025.exception;

import com.example.starter_project_2025.exception.error.ErrorResponse;
import com.example.starter_project_2025.exception.error.I18nErrorResponse;
import com.example.starter_project_2025.exception.error.ValidationErrorResponse;
import com.example.starter_project_2025.system.i18n.service.TooManyTextsException;
import com.example.starter_project_2025.system.i18n.service.UnsupportedLanguageException;
import com.example.starter_project_2025.system.project.StudentAlreadyAssignedException;
import com.example.starter_project_2025.system.project.AllocationSessionConflictException;
import com.example.starter_project_2025.system.project.IdempotencyKeyConflictException;
import com.example.starter_project_2025.system.project.IdempotencyRequestInProgressException;
import com.example.starter_project_2025.system.project.TeamCapacityExceededException;
import com.example.starter_project_2025.system.project.TeamErrorResponse;
import com.example.starter_project_2025.system.project.TeamNotDraftException;
import com.example.starter_project_2025.system.project.TeamTemplateCapacityExceededException;
import com.example.starter_project_2025.system.project.TeamTemplateErrorResponse;
import com.example.starter_project_2025.system.project.TeamRoleAssignmentErrorResponse;
import com.example.starter_project_2025.system.project.TeamRoleAssignmentException;
import com.example.starter_project_2025.system.project.TeamRolePolicyException;
import com.example.starter_project_2025.system.project.TeamVersionConflictException;
import com.example.starter_project_2025.system.project.InvalidMentorForClassException;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.validation.FieldError;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.security.authentication.LockedException;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(TeamRoleAssignmentException.class)
    public ResponseEntity<TeamRoleAssignmentErrorResponse> handleTeamRoleAssignment(
            TeamRoleAssignmentException ex
    ) {
        TeamRoleAssignmentErrorResponse response = new TeamRoleAssignmentErrorResponse(
                HttpStatus.UNPROCESSABLE_ENTITY.value(),
                "ERR_INVALID_TEAM_MEMBER_ROLES",
                ex.getMessage(),
                ex.getInvalidMemberIds(),
                List.of(),
                List.of(),
                LocalDateTime.now());
        return ResponseEntity.unprocessableEntity().body(response);
    }

    /**
     * US-11: template policy violations (multi-role disabled, role quota not
     * met, team leader must keep PM).
     */
    @ExceptionHandler(TeamRolePolicyException.class)
    public ResponseEntity<TeamRoleAssignmentErrorResponse> handleTeamRolePolicy(
            TeamRolePolicyException ex
    ) {
        TeamRoleAssignmentErrorResponse response = new TeamRoleAssignmentErrorResponse(
                HttpStatus.UNPROCESSABLE_ENTITY.value(),
                ex.getErrorCode(),
                ex.getMessage(),
                ex.getInvalidMemberIds(),
                ex.getViolations(),
                ex.getMultiRoleMemberIds(),
                LocalDateTime.now());
        return ResponseEntity.unprocessableEntity().body(response);
    }

    @ExceptionHandler(TeamVersionConflictException.class)
    public ResponseEntity<TeamErrorResponse> handleTeamVersionConflict(
            TeamVersionConflictException ex
    ) {
        return ResponseEntity.status(HttpStatus.CONFLICT).body(new TeamErrorResponse(
                HttpStatus.CONFLICT.value(),
                "ERR_TEAM_VERSION_CONFLICT",
                ex.getMessage(),
                null,
                null,
                LocalDateTime.now()));
    }

    @ExceptionHandler(AllocationSessionConflictException.class)
    public ResponseEntity<TeamErrorResponse> handleAllocationSessionConflict(
            AllocationSessionConflictException ex
    ) {
        TeamErrorResponse response = new TeamErrorResponse(
                HttpStatus.CONFLICT.value(),
                "ERR_ALLOCATION_SESSION_CONFLICT",
                ex.getMessage(),
                null,
                null,
                LocalDateTime.now()
        );
        return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
    }

    @ExceptionHandler(IdempotencyKeyConflictException.class)
    public ResponseEntity<TeamErrorResponse> handleIdempotencyKeyConflict(
            IdempotencyKeyConflictException ex
    ) {
        TeamErrorResponse response = new TeamErrorResponse(
                HttpStatus.CONFLICT.value(),
                "ERR_IDEMPOTENCY_KEY_REUSED",
                ex.getMessage(),
                null,
                null,
                LocalDateTime.now()
        );
        return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
    }

    @ExceptionHandler(IdempotencyRequestInProgressException.class)
    public ResponseEntity<TeamErrorResponse> handleIdempotencyRequestInProgress(
            IdempotencyRequestInProgressException ex
    ) {
        TeamErrorResponse response = new TeamErrorResponse(
                HttpStatus.CONFLICT.value(),
                "ERR_REQUEST_IN_PROGRESS",
                ex.getMessage(),
                null,
                null,
                LocalDateTime.now()
        );
        return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
    }

    @ExceptionHandler(TeamCapacityExceededException.class)
    public ResponseEntity<TeamErrorResponse> handleTeamCapacityExceeded(
            TeamCapacityExceededException ex
    ) {
        TeamErrorResponse response = new TeamErrorResponse(
                HttpStatus.UNPROCESSABLE_ENTITY.value(),
                "ERR_TEAM_CAPACITY_EXCEEDED",
                ex.getMessage(),
                null,
                null,
                LocalDateTime.now()
        );
        return ResponseEntity.unprocessableEntity().body(response);
    }

    @ExceptionHandler(com.example.starter_project_2025.system.project.AutoAllocationException.class)
    public ResponseEntity<TeamErrorResponse> handleAutoAllocation(
            com.example.starter_project_2025.system.project.AutoAllocationException ex) {
        return ResponseEntity.status(ex.getStatus()).body(new TeamErrorResponse(
                ex.getStatus().value(), ex.getCode(), ex.getMessage(),
                null, null, LocalDateTime.now()));
    }

    @ExceptionHandler(StudentAlreadyAssignedException.class)
    public ResponseEntity<TeamErrorResponse> handleStudentAlreadyAssigned(
            StudentAlreadyAssignedException ex
    ) {
        TeamErrorResponse response = new TeamErrorResponse(
                HttpStatus.CONFLICT.value(),
                "ERR_STUDENT_ALREADY_ASSIGNED",
                ex.getMessage(),
                ex.getMemberId(),
                ex.getConflictingTeamId(),
                LocalDateTime.now()
        );
        return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
    }

    /**
     * US-10 / AC02 + AC03: the DRAFT team size is outside the capacity window of
     * the selected project template. The contract requires HTTP 400 with the
     * {@code ERR_TEAM_CAPACITY_EXCEEDED} code for both directions.
     */
    @ExceptionHandler(TeamTemplateCapacityExceededException.class)
    public ResponseEntity<TeamTemplateErrorResponse> handleTeamTemplateCapacityExceeded(
            TeamTemplateCapacityExceededException ex
    ) {
        TeamTemplateErrorResponse response = new TeamTemplateErrorResponse(
                HttpStatus.BAD_REQUEST.value(),
                "ERR_TEAM_CAPACITY_EXCEEDED",
                ex.getReason().name(),
                ex.getMessage(),
                null,
                ex.getProjectTemplateId(),
                ex.getProjectTemplateName(),
                ex.getMemberCount(),
                ex.getMinMembers(),
                ex.getMaxMembers(),
                LocalDateTime.now()
        );
        return ResponseEntity.badRequest().body(response);
    }

    /** US-10: a project template can only be assigned to a DRAFT team. */
    @ExceptionHandler(TeamNotDraftException.class)
    public ResponseEntity<TeamTemplateErrorResponse> handleTeamNotDraft(
            TeamNotDraftException ex
    ) {
        TeamTemplateErrorResponse response = new TeamTemplateErrorResponse(
                HttpStatus.BAD_REQUEST.value(),
                "ERR_TEAM_NOT_DRAFT",
                ex.getTeamStatus() == null ? null : ex.getTeamStatus().name(),
                ex.getMessage(),
                ex.getTeamId(),
                null,
                null,
                null,
                null,
                null,
                LocalDateTime.now()
        );
        return ResponseEntity.badRequest().body(response);
    }

    /**
     * Ngôn ngữ đích không được hỗ trợ (chưa bật hoặc không tồn tại).
     *
     * <p>Giữ nguyên HTTP 400 như trước, thêm mã lỗi ổn định để frontend không phải so
     * message.
     */
    @ExceptionHandler(UnsupportedLanguageException.class)
    public ResponseEntity<I18nErrorResponse> handleUnsupportedLanguage(UnsupportedLanguageException ex) {
        log.warn("[400] Unsupported i18n target language: {}", ex.getLanguage());
        I18nErrorResponse error = new I18nErrorResponse(
                HttpStatus.BAD_REQUEST.value(),
                "ERR_I18N_UNSUPPORTED_LANGUAGE",
                ex.getMessage(),
                LocalDateTime.now());
        return ResponseEntity.badRequest().body(error);
    }

    /** Số chuỗi trong một request vượt quá giới hạn của backend. */
    @ExceptionHandler(TooManyTextsException.class)
    public ResponseEntity<I18nErrorResponse> handleTooManyTexts(TooManyTextsException ex) {
        log.warn("[400] Too many i18n texts, limit is {}", ex.getLimit());
        I18nErrorResponse error = new I18nErrorResponse(
                HttpStatus.BAD_REQUEST.value(),
                "ERR_I18N_TOO_MANY_TEXTS",
                ex.getMessage(),
                LocalDateTime.now());
        return ResponseEntity.badRequest().body(error);
    }

    @ExceptionHandler(org.springframework.web.servlet.resource.NoResourceFoundException.class)
    public ResponseEntity<ErrorResponse> handleNoResourceFound(
            org.springframework.web.servlet.resource.NoResourceFoundException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(
                new ErrorResponse(HttpStatus.NOT_FOUND.value(), "Resource was not found", LocalDateTime.now()));
    }

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleResourceNotFoundException(ResourceNotFoundException ex) {
        log.warn("[404] ResourceNotFound: {}", ex.getMessage());
        ErrorResponse error = new ErrorResponse(
                HttpStatus.NOT_FOUND.value(),
                ex.getMessage(),
                LocalDateTime.now());
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(BadRequestException.class)
    public ResponseEntity<ErrorResponse> handleBadRequestException(BadRequestException ex) {
        log.warn("[400] BadRequest: {}", ex.getMessage());
        ErrorResponse error = new ErrorResponse(
                HttpStatus.BAD_REQUEST.value(),
                ex.getMessage(),
                LocalDateTime.now());
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(ConflictException.class)
    public ResponseEntity<ErrorResponse> handleConflictException(ConflictException ex) {
        log.warn("[409] Conflict: {}", ex.getMessage());
        ErrorResponse error = new ErrorResponse(
                HttpStatus.CONFLICT.value(),
                ex.getMessage(),
                LocalDateTime.now());
        return new ResponseEntity<>(error, HttpStatus.CONFLICT);
    }

    @ExceptionHandler(InvalidMentorForClassException.class)
    public ResponseEntity<TeamErrorResponse> handleInvalidMentorForClass(
            InvalidMentorForClassException ex
    ) {
        return ResponseEntity.badRequest().body(new TeamErrorResponse(
                HttpStatus.BAD_REQUEST.value(),
                "ERR_INVALID_MENTOR_FOR_CLASS",
                InvalidMentorForClassException.MESSAGE,
                null,
                null,
                LocalDateTime.now()));
    }

    /** Giữ đúng status (401/404/...) thay vì bị handler RuntimeException đổi hết thành 400. */
    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<ErrorResponse> handleResponseStatusException(ResponseStatusException ex) {
        String message = ex.getReason() != null ? ex.getReason() : ex.getStatusCode().toString();
        ErrorResponse error = new ErrorResponse(
                ex.getStatusCode().value(),
                message,
                LocalDateTime.now());
        return new ResponseEntity<>(error, ex.getStatusCode());
    }

    @ExceptionHandler(UnauthorizedException.class)
    public ResponseEntity<ErrorResponse> handleUnauthorizedException(UnauthorizedException ex) {
        log.warn("[401] Unauthorized: {}", ex.getMessage());
        ErrorResponse error = new ErrorResponse(
                HttpStatus.UNAUTHORIZED.value(),
                ex.getMessage(),
                LocalDateTime.now());
        return new ResponseEntity<>(error, HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler(DisabledException.class)
    public ResponseEntity<ErrorResponse> handleDisabledException(DisabledException ex) {
        ErrorResponse error = new ErrorResponse(
                HttpStatus.FORBIDDEN.value(),
                ex.getMessage() != null && !ex.getMessage().isBlank()
                        ? ex.getMessage()
                        : "Account is deactivated or not active",
                LocalDateTime.now()
        );
        return new ResponseEntity<>(error, HttpStatus.FORBIDDEN);
    }

    @ExceptionHandler(ObjectOptimisticLockingFailureException.class)
    public ResponseEntity<ErrorResponse> handleOptimisticLockingFailure(ObjectOptimisticLockingFailureException ex) {
        log.warn("[409] OptimisticLockingFailure: {}", ex.getMessage());
        ErrorResponse error = new ErrorResponse(
                HttpStatus.CONFLICT.value(),
                "Data has been modified by another request. Please reload and try again.",
                LocalDateTime.now());
        return new ResponseEntity<>(error, HttpStatus.CONFLICT);
    }

    @ExceptionHandler(LockedException.class)
    public ResponseEntity<ErrorResponse> handleLockedException(
            LockedException ex) {

        ErrorResponse error = new ErrorResponse(
                HttpStatus.FORBIDDEN.value(),
                "Account is locked",
                LocalDateTime.now()
        );

        return new ResponseEntity<>(error, HttpStatus.FORBIDDEN);
    }

    @ExceptionHandler(BadCredentialsException.class)
    public ResponseEntity<ErrorResponse> handleBadCredentialsException(BadCredentialsException ex) {
        ErrorResponse error = new ErrorResponse(
                HttpStatus.UNAUTHORIZED.value(),
                "Invalid email or password",
                LocalDateTime.now());
        return new ResponseEntity<>(error, HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ErrorResponse> handleAccessDeniedException(AccessDeniedException ex) {
        ErrorResponse error = new ErrorResponse(
                HttpStatus.FORBIDDEN.value(),
                "You don't have permission to access this resource",
                LocalDateTime.now());
        return new ResponseEntity<>(error, HttpStatus.FORBIDDEN);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ValidationErrorResponse> handleValidation(MethodArgumentNotValidException ex) {

        Map<String, List<String>> errors = new HashMap<>();

        for (FieldError fieldError : ex.getBindingResult().getFieldErrors()) {

            errors.computeIfAbsent(
                    fieldError.getField(),
                    key -> new ArrayList<>()
            ).add(fieldError.getDefaultMessage());
        }

        ValidationErrorResponse response = new ValidationErrorResponse(
                "Validation failed",
                errors
        );

        return ResponseEntity.badRequest().body(response);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ValidationErrorResponse> handleConstraintViolation(ConstraintViolationException ex) {

        Map<String, List<String>> errors = new HashMap<>();

        for (ConstraintViolation<?> violation : ex.getConstraintViolations()) {

            String field = violation.getPropertyPath().toString();

            errors.computeIfAbsent(field, k -> new ArrayList<>())
                    .add(violation.getMessage());
        }

        ValidationErrorResponse response =
                new ValidationErrorResponse("Validation failed", errors);

        return ResponseEntity.badRequest().body(response);
    }

    @ExceptionHandler(BusinessValidationException.class)
    public ResponseEntity<ValidationErrorResponse> handleBusiness(BusinessValidationException ex) {

        ValidationErrorResponse response =
                new ValidationErrorResponse("Validation failed", ex.getErrors());

        return ResponseEntity.badRequest().body(response);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGlobalException(Exception ex) {
        ex.printStackTrace();
        String message = ex.getMessage() != null ? ex.getMessage() : ex.getClass().getSimpleName();
        ErrorResponse error = new ErrorResponse(
                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                "An unexpected error occurred: " + message,
                LocalDateTime.now());
        return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<ErrorResponse> handleMethodNotAllowed(HttpRequestMethodNotSupportedException ex) {
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(new ErrorResponse(
                HttpStatus.METHOD_NOT_ALLOWED.value(), ex.getMessage(), LocalDateTime.now()));
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ErrorResponse> handleIllegalArgumentException(IllegalArgumentException ex) {
        ErrorResponse error = new ErrorResponse(
                HttpStatus.BAD_REQUEST.value(),
                ex.getMessage(),
                LocalDateTime.now());
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<ErrorResponse> handleRuntimeException(RuntimeException ex) {
        ErrorResponse error = new ErrorResponse(
                HttpStatus.BAD_REQUEST.value(),
                ex.getMessage(),
                LocalDateTime.now());
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(com.example.starter_project_2025.system.external_api.exception.ExternalApiException.class)
    public ResponseEntity<ErrorResponse> handleExternalApiException(
            com.example.starter_project_2025.system.external_api.exception.ExternalApiException ex) {
        log.error("[ExternalAPI] {}", ex.getMessage());

        int status = ex.getStatusCode() > 0 ? ex.getStatusCode() : HttpStatus.SERVICE_UNAVAILABLE.value();
        // An upstream auth failure is not the caller's own 401/403: forwarding it would make the SPA log the user out.
        if (status == HttpStatus.UNAUTHORIZED.value() || status == HttpStatus.FORBIDDEN.value()) {
            status = HttpStatus.BAD_GATEWAY.value();
        }
        HttpStatus httpStatus = HttpStatus.resolve(status);
        if (httpStatus == null) {
            httpStatus = HttpStatus.SERVICE_UNAVAILABLE;
        }

        ErrorResponse error = new ErrorResponse(
                httpStatus.value(),
                ex.getMessage(),
                LocalDateTime.now());
        return new ResponseEntity<>(error, httpStatus);
    }
}
