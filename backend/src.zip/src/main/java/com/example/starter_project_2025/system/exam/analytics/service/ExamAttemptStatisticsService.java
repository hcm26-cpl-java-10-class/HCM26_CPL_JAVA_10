package com.example.starter_project_2025.system.exam.analytics.service;

import com.example.starter_project_2025.exception.BadRequestException;
import com.example.starter_project_2025.exception.ResourceNotFoundException;
import com.example.starter_project_2025.system.exam.grading.dto.AdjustScoreRequest;
import com.example.starter_project_2025.system.exam.analytics.dto.ExamAttemptStatisticsDTO;
import com.example.starter_project_2025.system.rbac.user.User;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.example.starter_project_2025.system.exam.attempt.domain.ExamAttempt;
import com.example.starter_project_2025.system.exam.attempt.domain.ExamAttemptRepository;
import com.example.starter_project_2025.system.exam.attempt.domain.ExamAttemptStatus;
import com.example.starter_project_2025.system.exam.core.domain.Exam;
import com.example.starter_project_2025.system.exam.core.domain.ExamRepository;
import com.example.starter_project_2025.system.exam.grading.domain.ExamScoreAdjustment;
import com.example.starter_project_2025.system.exam.grading.domain.ExamScoreAdjustmentRepository;
import com.example.starter_project_2025.system.exam.integrity.domain.ExamIntegrityEvent;
import com.example.starter_project_2025.system.exam.integrity.domain.ExamIntegrityEventRepository;
import com.example.starter_project_2025.system.exam.result.service.ExamResultReadinessService;
import com.example.starter_project_2025.system.exam.result.service.ExamResultStatisticsService;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class ExamAttemptStatisticsService {

    static final int MAX_REASON_LENGTH = 1000;

    private final ExamRepository examRepository;
    private final ExamAttemptRepository attemptRepository;
    private final ExamIntegrityEventRepository integrityEventRepository;
    private final ExamScoreAdjustmentRepository adjustmentRepository;
    private final ExamResultReadinessService readinessService;

    public List<ExamAttemptStatisticsDTO> getAttempts(Long examId) {
        Exam exam = examRepository.findById(examId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Exam not found"));

        BigDecimal passThreshold = ExamResultStatisticsService.resolvePassThreshold(exam);

        Map<Long, Long> violations = new HashMap<>();
        for (ExamIntegrityEvent e : integrityEventRepository.findAllByExamIdOrderByOccurredAtAsc(examId)) {
            violations.merge(e.getAttemptId(), 1L, Long::sum);
        }

        return attemptRepository.findAllByExam_Id(examId)
                .stream()
                .sorted(
                        Comparator.comparing(
                                ExamAttempt::getStartedAt,
                                Comparator.nullsLast(Comparator.naturalOrder())
                        ).reversed()
                )
                .map(a -> toDTO(a, violations.getOrDefault(a.getId(), 0L), passThreshold))
                .toList();
    }

    /** Ly do khong duoc sua; null neu duoc sua. Cho phep override co ly do + audit voi moi bai da cham xong (UFR-EXM-011). */
    public static String lockReason(ExamAttempt attempt, long violationCount) {
        if (attempt.getStatus() != ExamAttemptStatus.SUBMITTED || attempt.getFinalScore() == null) {
            return "Bài chưa chấm xong";
        }
        return null;
    }

    @Transactional
    public ExamAttemptStatisticsDTO adjustScore(Long examId, Long attemptId, AdjustScoreRequest request, Long userId) {
        ExamAttempt attempt = attemptRepository.lockById(attemptId)
                .orElseThrow(() -> new ResourceNotFoundException("Exam attempt not found"));
        if (!attempt.getExam().getId().equals(examId)) {
            throw new ResourceNotFoundException("Exam attempt not found");
        }

        long count = integrityEventRepository.countByAttemptId(attemptId);
        String locked = lockReason(attempt, count);
        if (locked != null) {
            throw new BadRequestException("Không thể sửa điểm: " + locked);
        }

        if (request == null || request.score() == null) {
            throw new BadRequestException("Vui lòng nhập điểm");
        }
        String reason = request.reason() == null ? "" : request.reason().trim();
        if (reason.isEmpty()) {
            throw new BadRequestException("Vui lòng nhập lý do sửa điểm");
        }
        if (reason.length() > MAX_REASON_LENGTH) {
            throw new BadRequestException("Lý do tối đa " + MAX_REASON_LENGTH + " ký tự");
        }

        BigDecimal score = request.score().setScale(4, RoundingMode.HALF_UP);
        if (score.signum() < 0) {
            throw new BadRequestException("Điểm không được âm");
        }
        BigDecimal max = attempt.getMaxScore();
        if (max != null && score.compareTo(max) > 0) {
            throw new BadRequestException("Điểm không được vượt quá điểm tối đa (" + max.stripTrailingZeros().toPlainString() + ")");
        }

        ExamScoreAdjustment log = new ExamScoreAdjustment();
        log.setAttemptId(attemptId);
        log.setExamId(examId);
        if (attempt.getFirstScore() == null) {
            attempt.setFirstScore(attempt.getFinalScore());
        }
        log.setOldScore(attempt.getFinalScore());
        log.setNewScore(score);
        log.setReason(reason);
        log.setAdjustedBy(userId);
        log.setAdjustedAt(Instant.now());
        adjustmentRepository.save(log);

        attempt.setFinalScore(score);
        attemptRepository.save(attempt);

        BigDecimal passThreshold = ExamResultStatisticsService.resolvePassThreshold(attempt.getExam());

        return toDTO(attempt, count, passThreshold);
    }

    private ExamAttemptStatisticsDTO toDTO(ExamAttempt attempt, long violationCount, BigDecimal passThreshold) {
        User student = attempt.getStudent();

        String studentName = "";
        String studentEmail = "";

        if (student != null) {
            String firstName = student.getFirstName() == null
                    ? "" : student.getFirstName().trim();

            String lastName = student.getLastName() == null
                    ? "" : student.getLastName().trim();

            studentName = (firstName + " " + lastName).trim();
            studentEmail = student.getEmail() == null
                    ? "" : student.getEmail();
        }

        String locked = lockReason(attempt, violationCount);

        Boolean passed = null;
        if (readinessService.isFullyGraded(attempt) && attempt.getFinalScore() != null) {
            passed = attempt.getFinalScore().compareTo(passThreshold) >= 0;
        }

        return new ExamAttemptStatisticsDTO(
                attempt.getId(),
                student == null ? null : student.getId(),
                studentName,
                studentEmail,
                attempt.getAttemptNumber(),
                attempt.getStartedAt(),
                attempt.getSubmittedAt(),
                attempt.getFinalScore(),
                attempt.getStatus(),
                attempt.getMaxScore(),
                attempt.getFirstScore(),
                attempt.getFirstScore() == null ? null : attempt.getFinalScore(),
                violationCount > 0,
                violationCount,
                locked == null,
                locked,
                passed
        );
    }
}
