package com.example.starter_project_2025;

import com.example.starter_project_2025.config.DotenvLoader;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@EnableAsync(proxyTargetClass = true)
@SpringBootApplication
public class StarterProject2025Application {

	public static void main(String[] args) {
		DotenvLoader.load();
		SpringApplication.run(StarterProject2025Application.class, args);
	}

}
